import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../b88efbbf-2a9a-47b4-86e1-e38ecc2b433b/src/item"
import Script2 from "../5caa95dd-9d2f-42e1-b935-0da1a287864a/src/item"
import Script3 from "../da30258e-3cc1-48a4-bc55-508e923ae977/src/item"
import Script4 from "../6d694c78-6dd5-4a4d-acee-21dbf67dd464/src/item"
import Script5 from "../3e3df11c-8e39-4494-ac4e-d6faab495f13/src/item"
import Script6 from "../eced91a9-934c-4bcb-94cc-2be8264ad942/src/item"
import Script7 from "../552af2d3-4de2-4e12-be02-637e97a1e7da/src/item"
import Script8 from "../06c23898-6653-4343-b4d1-94bd343c8740/src/item"
import Script9 from "../58dc566a-2add-4326-b61c-0fdf46903195/src/item"
import Script10 from "../b8755ec2-a4a1-4b3d-be0a-db5a2185d3b7/src/item"
import Script11 from "../51ff7609-407f-481d-991b-8449ef59b390/src/item"
import Script12 from "../7cd4d0bc-54d4-4f64-8ab2-6f18f41f03a3/src/item"
import Script13 from "../80d9cb1c-2fcf-4585-8e19-e2d5621fd54d/src/item"
import Script14 from "../a747f104-5434-42a8-a543-8739c24cf253/src/item"
import Script15 from "../69695443-7b21-4caa-9bf9-4147bab4ab6c/src/item"
import Script16 from "../8cfbe9ef-1b3e-4f3a-ad5e-f6bd8d421f42/src/item"
import Script17 from "../622ebd59-591b-41b0-b989-6b4a4931f315/src/item"
import Script18 from "../43166e90-5f00-4d06-ab07-8cefae85cbd1/src/item"
import Script19 from "../6f380825-70bb-42f9-8dce-57563c7ac582/src/item"
import Script20 from "../7d669c08-c354-45e4-b3a3-c915c8fd6b6e/src/item"
import Script21 from "../c5cbd030-54d0-4f28-9158-d27401c691b1/src/item"
import Script22 from "../1da1a2be-bd68-4e35-bd89-42280b39291c/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const externalLink = new Entity('externalLink')
engine.addEntity(externalLink)
externalLink.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(0.3096649646759033, 2.15470027923584, 6.009059906005859),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.4999999701976776, 0.5000000596046448),
  scale: new Vector3(1.0000056028366089, 1.0000054836273193, 1.0000053644180298)
})
externalLink.addComponentOrReplace(transform2)

const openAndClosedSign = new Entity('openAndClosedSign')
engine.addEntity(openAndClosedSign)
openAndClosedSign.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(6.5, 2.5, 3.9795374870300293),
  rotation: new Quaternion(6.691670821108589e-15, -1, 1.1920927533992653e-7, -7.450580596923828e-8),
  scale: new Vector3(0.9036524295806885, 1.0278236865997314, 0.9999998807907104)
})
openAndClosedSign.addComponentOrReplace(transform3)

const speakers = new Entity('speakers')
engine.addEntity(speakers)
speakers.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(12.887401580810547, 1.999998927116394, 4.713125228881836),
  rotation: new Quaternion(0, 6.058451752097371e-28, 5.082197683525802e-21, -1),
  scale: new Vector3(1, 1, 1)
})
speakers.addComponentOrReplace(transform4)

const scifiChest = new Entity('scifiChest')
engine.addEntity(scifiChest)
scifiChest.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(7.5, 4.279685020446777, 5),
  rotation: new Quaternion(2.2649851591993123e-15, 0, 8.333807613780311e-17, -1),
  scale: new Vector3(1.0000033378601074, 1, 1.0000033378601074)
})
scifiChest.addComponentOrReplace(transform5)

const atomicLight = new Entity('atomicLight')
engine.addEntity(atomicLight)
atomicLight.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(12.5, 4.5, 6.363226890563965),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
atomicLight.addComponentOrReplace(transform6)

const ceilingFan = new Entity('ceilingFan')
engine.addEntity(ceilingFan)
ceilingFan.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(12, 3.7534446716308594, 10),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
ceilingFan.addComponentOrReplace(transform7)

const ceilingLight = new Entity('ceilingLight')
engine.addEntity(ceilingLight)
ceilingLight.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(1.2878069877624512, 0, 6.262248516082764),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
ceilingLight.addComponentOrReplace(transform8)

const imageComputerScreen = new Entity('imageComputerScreen')
engine.addEntity(imageComputerScreen)
imageComputerScreen.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(1.1425013542175293, 1.0068150758743286, 13.762248039245605),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000028610229492, 1, 1.0000028610229492)
})
imageComputerScreen.addComponentOrReplace(transform9)

const concreteWall4 = new Entity('concreteWall4')
engine.addEntity(concreteWall4)
concreteWall4.setParent(_scene)
const gltfShape = new GLTFShape("53aa3052-ccd7-4a05-be3f-f840acbff99e/Concrete_Wall.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
concreteWall4.addComponentOrReplace(gltfShape)
const transform10 = new Transform({
  position: new Vector3(9, 0, 4),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(0.5099999308586121, 1, 0.9999999403953552)
})
concreteWall4.addComponentOrReplace(transform10)

const verticalPlatform = new Entity('verticalPlatform')
engine.addEntity(verticalPlatform)
verticalPlatform.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(8, 0, 14),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
verticalPlatform.addComponentOrReplace(transform11)

const fourSeatRow = new Entity('fourSeatRow')
engine.addEntity(fourSeatRow)
fourSeatRow.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(1, 4.295651912689209, 8.5),
  rotation: new Quaternion(-1.1858019110361738e-14, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.000004529953003, 1, 1.000004529953003)
})
fourSeatRow.addComponentOrReplace(transform12)
const gltfShape2 = new GLTFShape("99a1953e-c091-45be-a642-47448565b781/Seats_01/Seats_01.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
fourSeatRow.addComponentOrReplace(gltfShape2)

const radiatorDroid = new Entity('radiatorDroid')
engine.addEntity(radiatorDroid)
radiatorDroid.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(15, 5.5, 8),
  rotation: new Quaternion(8.692207211977426e-15, -0.9238795638084412, 1.1013502643208994e-7, 0.3826833963394165),
  scale: new Vector3(1.0000008344650269, 1, 1.0000008344650269)
})
radiatorDroid.addComponentOrReplace(transform13)
const gltfShape3 = new GLTFShape("934550f8-49fd-4999-b0d5-aa461945e293/Droid_02/Droid_02.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
radiatorDroid.addComponentOrReplace(gltfShape3)

const keyboard3 = new Entity('keyboard3')
engine.addEntity(keyboard3)
keyboard3.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(1.433112621307373, 1.0032227039337158, 13.762248039245605),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000028610229492, 1, 1.0000028610229492)
})
keyboard3.addComponentOrReplace(transform14)

const uprightWorkTable2 = new Entity('uprightWorkTable2')
engine.addEntity(uprightWorkTable2)
uprightWorkTable2.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(1.2224373817443848, 9.5367431640625e-7, 13.762248039245605),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000028610229492, 1, 1.0000028610229492)
})
uprightWorkTable2.addComponentOrReplace(transform15)
const gltfShape4 = new GLTFShape("d2d2febd-e168-4127-b432-50164e5e0c84/TableSciFi_01/TableSciFi_01.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
uprightWorkTable2.addComponentOrReplace(gltfShape4)

const concreteWall2 = new Entity('concreteWall2')
engine.addEntity(concreteWall2)
concreteWall2.setParent(_scene)
concreteWall2.addComponentOrReplace(gltfShape)
const transform16 = new Transform({
  position: new Vector3(6, 0, 4),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(0.5099999308586121, 1, 0.9999999403953552)
})
concreteWall2.addComponentOrReplace(transform16)

const ceilingFan2 = new Entity('ceilingFan2')
engine.addEntity(ceilingFan2)
ceilingFan2.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(3.5, 3.749598503112793, 10),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
ceilingFan2.addComponentOrReplace(transform17)

const windowBlackLarge = new Entity('windowBlackLarge')
engine.addEntity(windowBlackLarge)
windowBlackLarge.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(4, 0, 4.005232810974121),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
windowBlackLarge.addComponentOrReplace(transform18)
const gltfShape5 = new GLTFShape("3480f2f9-fd1a-43c8-a84f-9fe443aff7e9/BlackWindowLarge.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
windowBlackLarge.addComponentOrReplace(gltfShape5)

const windowBlackLarge2 = new Entity('windowBlackLarge2')
engine.addEntity(windowBlackLarge2)
windowBlackLarge2.setParent(_scene)
windowBlackLarge2.addComponentOrReplace(gltfShape5)
const transform19 = new Transform({
  position: new Vector3(10, 0, 4),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
windowBlackLarge2.addComponentOrReplace(transform19)

const concreteWall3 = new Entity('concreteWall3')
engine.addEntity(concreteWall3)
concreteWall3.setParent(_scene)
concreteWall3.addComponentOrReplace(gltfShape)
const transform20 = new Transform({
  position: new Vector3(3, 0, 4.005232810974121),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(0.5099999308586121, 1, 0.9999999403953552)
})
concreteWall3.addComponentOrReplace(transform20)

const windowBlackLarge3 = new Entity('windowBlackLarge3')
engine.addEntity(windowBlackLarge3)
windowBlackLarge3.setParent(_scene)
windowBlackLarge3.addComponentOrReplace(gltfShape5)
const transform21 = new Transform({
  position: new Vector3(1, 0, 4.005232810974121),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
windowBlackLarge3.addComponentOrReplace(transform21)

const concreteWall5 = new Entity('concreteWall5')
engine.addEntity(concreteWall5)
concreteWall5.setParent(_scene)
concreteWall5.addComponentOrReplace(gltfShape)
const transform22 = new Transform({
  position: new Vector3(0, 0, 4.005232810974121),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(0.5099999308586121, 1, 0.9999999403953552)
})
concreteWall5.addComponentOrReplace(transform22)

const concreteWall12 = new Entity('concreteWall12')
engine.addEntity(concreteWall12)
concreteWall12.setParent(_scene)
concreteWall12.addComponentOrReplace(gltfShape)
const transform23 = new Transform({
  position: new Vector3(12, 0, 4),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(0.5099999308586121, 1, 0.9999999403953552)
})
concreteWall12.addComponentOrReplace(transform23)

const windowBlackLarge4 = new Entity('windowBlackLarge4')
engine.addEntity(windowBlackLarge4)
windowBlackLarge4.setParent(_scene)
windowBlackLarge4.addComponentOrReplace(gltfShape5)
const transform24 = new Transform({
  position: new Vector3(13, 0, 4),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
windowBlackLarge4.addComponentOrReplace(transform24)

const concreteWall13 = new Entity('concreteWall13')
engine.addEntity(concreteWall13)
concreteWall13.setParent(_scene)
concreteWall13.addComponentOrReplace(gltfShape)
const transform25 = new Transform({
  position: new Vector3(14.97641658782959, 0, 4),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(0.5099999308586121, 1, 0.9999999403953552)
})
concreteWall13.addComponentOrReplace(transform25)

const speakers2 = new Entity('speakers2')
engine.addEntity(speakers2)
speakers2.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(3.8909912109375, 1.999998927116394, 4.728721618652344),
  rotation: new Quaternion(0, 6.058451752097371e-28, 5.082197683525802e-21, -1),
  scale: new Vector3(1, 1, 1)
})
speakers2.addComponentOrReplace(transform26)

const keyboard = new Entity('keyboard')
engine.addEntity(keyboard)
keyboard.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(1.433112621307373, 1.003222107887268, 11.262248039245605),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000035762786865, 1, 1.0000035762786865)
})
keyboard.addComponentOrReplace(transform27)

const uprightWorkTable = new Entity('uprightWorkTable')
engine.addEntity(uprightWorkTable)
uprightWorkTable.setParent(_scene)
uprightWorkTable.addComponentOrReplace(gltfShape4)
const transform28 = new Transform({
  position: new Vector3(1.2224373817443848, 3.5762786865234375e-7, 11.262248039245605),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000035762786865, 1, 1.0000035762786865)
})
uprightWorkTable.addComponentOrReplace(transform28)

const imageComputerScreen2 = new Entity('imageComputerScreen2')
engine.addEntity(imageComputerScreen2)
imageComputerScreen2.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(1.1425013542175293, 1.0068144798278809, 11.262248039245605),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000035762786865, 1, 1.0000035762786865)
})
imageComputerScreen2.addComponentOrReplace(transform29)

const keyboard4 = new Entity('keyboard4')
engine.addEntity(keyboard4)
keyboard4.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(1.433112621307373, 1.0032215118408203, 8.762248039245605),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000042915344238, 1, 1.0000042915344238)
})
keyboard4.addComponentOrReplace(transform30)

const uprightWorkTable4 = new Entity('uprightWorkTable4')
engine.addEntity(uprightWorkTable4)
uprightWorkTable4.setParent(_scene)
uprightWorkTable4.addComponentOrReplace(gltfShape4)
const transform31 = new Transform({
  position: new Vector3(1.2224373817443848, 0, 8.762248039245605),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000042915344238, 1, 1.0000042915344238)
})
uprightWorkTable4.addComponentOrReplace(transform31)

const imageComputerScreen4 = new Entity('imageComputerScreen4')
engine.addEntity(imageComputerScreen4)
imageComputerScreen4.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(1.1425013542175293, 1.006813883781433, 8.762248039245605),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000042915344238, 1, 1.0000042915344238)
})
imageComputerScreen4.addComponentOrReplace(transform32)

const keyboard5 = new Entity('keyboard5')
engine.addEntity(keyboard5)
keyboard5.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(1.433112621307373, 1.0032209157943726, 6.2622480392456055),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.000004529953003, 1, 1.000004529953003)
})
keyboard5.addComponentOrReplace(transform33)

const uprightWorkTable5 = new Entity('uprightWorkTable5')
engine.addEntity(uprightWorkTable5)
uprightWorkTable5.setParent(_scene)
uprightWorkTable5.addComponentOrReplace(gltfShape4)
const transform34 = new Transform({
  position: new Vector3(1.2224373817443848, 0, 6.262248516082764),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.000004529953003, 1, 1.000004529953003)
})
uprightWorkTable5.addComponentOrReplace(transform34)

const imageComputerScreen5 = new Entity('imageComputerScreen5')
engine.addEntity(imageComputerScreen5)
imageComputerScreen5.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(1.1425013542175293, 1.0068132877349854, 6.2622480392456055),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.000004529953003, 1, 1.000004529953003)
})
imageComputerScreen5.addComponentOrReplace(transform35)

const externalLink5 = new Entity('externalLink5')
engine.addEntity(externalLink5)
externalLink5.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(0.3106873035430908, 2.154700994491577, 8.514491081237793),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.4999999701976776, 0.5000000596046448),
  scale: new Vector3(1.0000063180923462, 1.0000061988830566, 1.000006079673767)
})
externalLink5.addComponentOrReplace(transform36)

const externalLink6 = new Entity('externalLink6')
engine.addEntity(externalLink6)
externalLink6.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(0.3153069019317627, 2.1547014713287354, 11.020676612854004),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.4999999701976776, 0.5000000596046448),
  scale: new Vector3(1.0000070333480835, 1.000006914138794, 1.0000067949295044)
})
externalLink6.addComponentOrReplace(transform37)

const externalLink7 = new Entity('externalLink7')
engine.addEntity(externalLink7)
externalLink7.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(0.3165881633758545, 2.1547021865844727, 13.540607452392578),
  rotation: new Quaternion(0.5000000596046448, 0.5000000596046448, 0.4999999701976776, 0.5000000596046448),
  scale: new Vector3(1.0000077486038208, 1.0000076293945312, 1.0000075101852417)
})
externalLink7.addComponentOrReplace(transform38)

const ceilingLight2 = new Entity('ceilingLight2')
engine.addEntity(ceilingLight2)
ceilingLight2.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(1.2878069877624512, 0, 8.762248039245605),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
ceilingLight2.addComponentOrReplace(transform39)

const ceilingLight3 = new Entity('ceilingLight3')
engine.addEntity(ceilingLight3)
ceilingLight3.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(1.2878069877624512, 3.5762786865234375e-7, 11.262248039245605),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
ceilingLight3.addComponentOrReplace(transform40)

const ceilingLight4 = new Entity('ceilingLight4')
engine.addEntity(ceilingLight4)
ceilingLight4.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(1.2878074645996094, 9.5367431640625e-7, 13.762248039245605),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
ceilingLight4.addComponentOrReplace(transform41)

const fourSquareFloorPanel = new Entity('fourSquareFloorPanel')
engine.addEntity(fourSquareFloorPanel)
fourSquareFloorPanel.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(16, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel.addComponentOrReplace(transform42)
const gltfShape6 = new GLTFShape("06f65cfc-1013-4506-930f-ff759561185d/FloorSciFiPanel_02/FloorSciFiPanel_02.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
fourSquareFloorPanel.addComponentOrReplace(gltfShape6)

const fourSquareFloorPanel2 = new Entity('fourSquareFloorPanel2')
engine.addEntity(fourSquareFloorPanel2)
fourSquareFloorPanel2.setParent(_scene)
fourSquareFloorPanel2.addComponentOrReplace(gltfShape6)
const transform43 = new Transform({
  position: new Vector3(14, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel2.addComponentOrReplace(transform43)

const fourSquareFloorPanel3 = new Entity('fourSquareFloorPanel3')
engine.addEntity(fourSquareFloorPanel3)
fourSquareFloorPanel3.setParent(_scene)
fourSquareFloorPanel3.addComponentOrReplace(gltfShape6)
const transform44 = new Transform({
  position: new Vector3(16, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel3.addComponentOrReplace(transform44)

const fourSquareFloorPanel4 = new Entity('fourSquareFloorPanel4')
engine.addEntity(fourSquareFloorPanel4)
fourSquareFloorPanel4.setParent(_scene)
fourSquareFloorPanel4.addComponentOrReplace(gltfShape6)
const transform45 = new Transform({
  position: new Vector3(16, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel4.addComponentOrReplace(transform45)

const fourSquareFloorPanel5 = new Entity('fourSquareFloorPanel5')
engine.addEntity(fourSquareFloorPanel5)
fourSquareFloorPanel5.setParent(_scene)
fourSquareFloorPanel5.addComponentOrReplace(gltfShape6)
const transform46 = new Transform({
  position: new Vector3(16, 0, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel5.addComponentOrReplace(transform46)

const fourSquareFloorPanel6 = new Entity('fourSquareFloorPanel6')
engine.addEntity(fourSquareFloorPanel6)
fourSquareFloorPanel6.setParent(_scene)
fourSquareFloorPanel6.addComponentOrReplace(gltfShape6)
const transform47 = new Transform({
  position: new Vector3(16, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel6.addComponentOrReplace(transform47)

const fourSquareFloorPanel7 = new Entity('fourSquareFloorPanel7')
engine.addEntity(fourSquareFloorPanel7)
fourSquareFloorPanel7.setParent(_scene)
fourSquareFloorPanel7.addComponentOrReplace(gltfShape6)
const transform48 = new Transform({
  position: new Vector3(14, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel7.addComponentOrReplace(transform48)

const fourSquareFloorPanel8 = new Entity('fourSquareFloorPanel8')
engine.addEntity(fourSquareFloorPanel8)
fourSquareFloorPanel8.setParent(_scene)
fourSquareFloorPanel8.addComponentOrReplace(gltfShape6)
const transform49 = new Transform({
  position: new Vector3(14, 0, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel8.addComponentOrReplace(transform49)

const fourSquareFloorPanel9 = new Entity('fourSquareFloorPanel9')
engine.addEntity(fourSquareFloorPanel9)
fourSquareFloorPanel9.setParent(_scene)
fourSquareFloorPanel9.addComponentOrReplace(gltfShape6)
const transform50 = new Transform({
  position: new Vector3(14, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel9.addComponentOrReplace(transform50)

const fourSquareFloorPanel10 = new Entity('fourSquareFloorPanel10')
engine.addEntity(fourSquareFloorPanel10)
fourSquareFloorPanel10.setParent(_scene)
fourSquareFloorPanel10.addComponentOrReplace(gltfShape6)
const transform51 = new Transform({
  position: new Vector3(14, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel10.addComponentOrReplace(transform51)

const fourSquareFloorPanel11 = new Entity('fourSquareFloorPanel11')
engine.addEntity(fourSquareFloorPanel11)
fourSquareFloorPanel11.setParent(_scene)
fourSquareFloorPanel11.addComponentOrReplace(gltfShape6)
const transform52 = new Transform({
  position: new Vector3(12, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel11.addComponentOrReplace(transform52)

const fourSquareFloorPanel12 = new Entity('fourSquareFloorPanel12')
engine.addEntity(fourSquareFloorPanel12)
fourSquareFloorPanel12.setParent(_scene)
fourSquareFloorPanel12.addComponentOrReplace(gltfShape6)
const transform53 = new Transform({
  position: new Vector3(12, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel12.addComponentOrReplace(transform53)

const fourSquareFloorPanel13 = new Entity('fourSquareFloorPanel13')
engine.addEntity(fourSquareFloorPanel13)
fourSquareFloorPanel13.setParent(_scene)
fourSquareFloorPanel13.addComponentOrReplace(gltfShape6)
const transform54 = new Transform({
  position: new Vector3(12, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel13.addComponentOrReplace(transform54)

const fourSquareFloorPanel14 = new Entity('fourSquareFloorPanel14')
engine.addEntity(fourSquareFloorPanel14)
fourSquareFloorPanel14.setParent(_scene)
fourSquareFloorPanel14.addComponentOrReplace(gltfShape6)
const transform55 = new Transform({
  position: new Vector3(12, 0, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel14.addComponentOrReplace(transform55)

const fourSquareFloorPanel15 = new Entity('fourSquareFloorPanel15')
engine.addEntity(fourSquareFloorPanel15)
fourSquareFloorPanel15.setParent(_scene)
fourSquareFloorPanel15.addComponentOrReplace(gltfShape6)
const transform56 = new Transform({
  position: new Vector3(12, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel15.addComponentOrReplace(transform56)

const fourSquareFloorPanel16 = new Entity('fourSquareFloorPanel16')
engine.addEntity(fourSquareFloorPanel16)
fourSquareFloorPanel16.setParent(_scene)
fourSquareFloorPanel16.addComponentOrReplace(gltfShape6)
const transform57 = new Transform({
  position: new Vector3(10, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel16.addComponentOrReplace(transform57)

const fourSquareFloorPanel17 = new Entity('fourSquareFloorPanel17')
engine.addEntity(fourSquareFloorPanel17)
fourSquareFloorPanel17.setParent(_scene)
fourSquareFloorPanel17.addComponentOrReplace(gltfShape6)
const transform58 = new Transform({
  position: new Vector3(10, 0, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel17.addComponentOrReplace(transform58)

const fourSquareFloorPanel18 = new Entity('fourSquareFloorPanel18')
engine.addEntity(fourSquareFloorPanel18)
fourSquareFloorPanel18.setParent(_scene)
fourSquareFloorPanel18.addComponentOrReplace(gltfShape6)
const transform59 = new Transform({
  position: new Vector3(10, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel18.addComponentOrReplace(transform59)

const fourSquareFloorPanel19 = new Entity('fourSquareFloorPanel19')
engine.addEntity(fourSquareFloorPanel19)
fourSquareFloorPanel19.setParent(_scene)
fourSquareFloorPanel19.addComponentOrReplace(gltfShape6)
const transform60 = new Transform({
  position: new Vector3(10, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel19.addComponentOrReplace(transform60)

const fourSquareFloorPanel20 = new Entity('fourSquareFloorPanel20')
engine.addEntity(fourSquareFloorPanel20)
fourSquareFloorPanel20.setParent(_scene)
fourSquareFloorPanel20.addComponentOrReplace(gltfShape6)
const transform61 = new Transform({
  position: new Vector3(10, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel20.addComponentOrReplace(transform61)

const fourSquareFloorPanel21 = new Entity('fourSquareFloorPanel21')
engine.addEntity(fourSquareFloorPanel21)
fourSquareFloorPanel21.setParent(_scene)
fourSquareFloorPanel21.addComponentOrReplace(gltfShape6)
const transform62 = new Transform({
  position: new Vector3(8, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel21.addComponentOrReplace(transform62)

const fourSquareFloorPanel22 = new Entity('fourSquareFloorPanel22')
engine.addEntity(fourSquareFloorPanel22)
fourSquareFloorPanel22.setParent(_scene)
fourSquareFloorPanel22.addComponentOrReplace(gltfShape6)
const transform63 = new Transform({
  position: new Vector3(6, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel22.addComponentOrReplace(transform63)

const fourSquareFloorPanel23 = new Entity('fourSquareFloorPanel23')
engine.addEntity(fourSquareFloorPanel23)
fourSquareFloorPanel23.setParent(_scene)
fourSquareFloorPanel23.addComponentOrReplace(gltfShape6)
const transform64 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel23.addComponentOrReplace(transform64)

const fourSquareFloorPanel24 = new Entity('fourSquareFloorPanel24')
engine.addEntity(fourSquareFloorPanel24)
fourSquareFloorPanel24.setParent(_scene)
fourSquareFloorPanel24.addComponentOrReplace(gltfShape6)
const transform65 = new Transform({
  position: new Vector3(8, 0, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel24.addComponentOrReplace(transform65)

const fourSquareFloorPanel25 = new Entity('fourSquareFloorPanel25')
engine.addEntity(fourSquareFloorPanel25)
fourSquareFloorPanel25.setParent(_scene)
fourSquareFloorPanel25.addComponentOrReplace(gltfShape6)
const transform66 = new Transform({
  position: new Vector3(8, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel25.addComponentOrReplace(transform66)

const fourSquareFloorPanel26 = new Entity('fourSquareFloorPanel26')
engine.addEntity(fourSquareFloorPanel26)
fourSquareFloorPanel26.setParent(_scene)
fourSquareFloorPanel26.addComponentOrReplace(gltfShape6)
const transform67 = new Transform({
  position: new Vector3(2, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel26.addComponentOrReplace(transform67)

const fourSquareFloorPanel27 = new Entity('fourSquareFloorPanel27')
engine.addEntity(fourSquareFloorPanel27)
fourSquareFloorPanel27.setParent(_scene)
fourSquareFloorPanel27.addComponentOrReplace(gltfShape6)
const transform68 = new Transform({
  position: new Vector3(2, 0, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel27.addComponentOrReplace(transform68)

const fourSquareFloorPanel28 = new Entity('fourSquareFloorPanel28')
engine.addEntity(fourSquareFloorPanel28)
fourSquareFloorPanel28.setParent(_scene)
fourSquareFloorPanel28.addComponentOrReplace(gltfShape6)
const transform69 = new Transform({
  position: new Vector3(2, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel28.addComponentOrReplace(transform69)

const fourSquareFloorPanel29 = new Entity('fourSquareFloorPanel29')
engine.addEntity(fourSquareFloorPanel29)
fourSquareFloorPanel29.setParent(_scene)
fourSquareFloorPanel29.addComponentOrReplace(gltfShape6)
const transform70 = new Transform({
  position: new Vector3(4, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel29.addComponentOrReplace(transform70)

const fourSquareFloorPanel30 = new Entity('fourSquareFloorPanel30')
engine.addEntity(fourSquareFloorPanel30)
fourSquareFloorPanel30.setParent(_scene)
fourSquareFloorPanel30.addComponentOrReplace(gltfShape6)
const transform71 = new Transform({
  position: new Vector3(2, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel30.addComponentOrReplace(transform71)

const fourSquareFloorPanel31 = new Entity('fourSquareFloorPanel31')
engine.addEntity(fourSquareFloorPanel31)
fourSquareFloorPanel31.setParent(_scene)
fourSquareFloorPanel31.addComponentOrReplace(gltfShape6)
const transform72 = new Transform({
  position: new Vector3(4, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel31.addComponentOrReplace(transform72)

const fourSquareFloorPanel32 = new Entity('fourSquareFloorPanel32')
engine.addEntity(fourSquareFloorPanel32)
fourSquareFloorPanel32.setParent(_scene)
fourSquareFloorPanel32.addComponentOrReplace(gltfShape6)
const transform73 = new Transform({
  position: new Vector3(2, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel32.addComponentOrReplace(transform73)

const fourSquareFloorPanel33 = new Entity('fourSquareFloorPanel33')
engine.addEntity(fourSquareFloorPanel33)
fourSquareFloorPanel33.setParent(_scene)
fourSquareFloorPanel33.addComponentOrReplace(gltfShape6)
const transform74 = new Transform({
  position: new Vector3(6, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel33.addComponentOrReplace(transform74)

const fourSquareFloorPanel34 = new Entity('fourSquareFloorPanel34')
engine.addEntity(fourSquareFloorPanel34)
fourSquareFloorPanel34.setParent(_scene)
fourSquareFloorPanel34.addComponentOrReplace(gltfShape6)
const transform75 = new Transform({
  position: new Vector3(4, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel34.addComponentOrReplace(transform75)

const fourSquareFloorPanel35 = new Entity('fourSquareFloorPanel35')
engine.addEntity(fourSquareFloorPanel35)
fourSquareFloorPanel35.setParent(_scene)
fourSquareFloorPanel35.addComponentOrReplace(gltfShape6)
const transform76 = new Transform({
  position: new Vector3(4, 0, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel35.addComponentOrReplace(transform76)

const fourSquareFloorPanel36 = new Entity('fourSquareFloorPanel36')
engine.addEntity(fourSquareFloorPanel36)
fourSquareFloorPanel36.setParent(_scene)
fourSquareFloorPanel36.addComponentOrReplace(gltfShape6)
const transform77 = new Transform({
  position: new Vector3(4, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel36.addComponentOrReplace(transform77)

const fourSquareFloorPanel37 = new Entity('fourSquareFloorPanel37')
engine.addEntity(fourSquareFloorPanel37)
fourSquareFloorPanel37.setParent(_scene)
fourSquareFloorPanel37.addComponentOrReplace(gltfShape6)
const transform78 = new Transform({
  position: new Vector3(6, 0, 12),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel37.addComponentOrReplace(transform78)

const fourSquareFloorPanel38 = new Entity('fourSquareFloorPanel38')
engine.addEntity(fourSquareFloorPanel38)
fourSquareFloorPanel38.setParent(_scene)
fourSquareFloorPanel38.addComponentOrReplace(gltfShape6)
const transform79 = new Transform({
  position: new Vector3(6, 0, 10),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel38.addComponentOrReplace(transform79)

const fourSquareFloorPanel39 = new Entity('fourSquareFloorPanel39')
engine.addEntity(fourSquareFloorPanel39)
fourSquareFloorPanel39.setParent(_scene)
fourSquareFloorPanel39.addComponentOrReplace(gltfShape6)
const transform80 = new Transform({
  position: new Vector3(6, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel39.addComponentOrReplace(transform80)

const fourSquareFloorPanel40 = new Entity('fourSquareFloorPanel40')
engine.addEntity(fourSquareFloorPanel40)
fourSquareFloorPanel40.setParent(_scene)
fourSquareFloorPanel40.addComponentOrReplace(gltfShape6)
const transform81 = new Transform({
  position: new Vector3(8, 0, 16),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel40.addComponentOrReplace(transform81)

const blueLightButton = new Entity('blueLightButton')
engine.addEntity(blueLightButton)
blueLightButton.setParent(_scene)
const transform82 = new Transform({
  position: new Vector3(6.5, 1.5, 4.004180908203125),
  rotation: new Quaternion(-0.7071068286895752, -1.7038924931362873e-14, 8.429367426288081e-8, 0.7071068286895752),
  scale: new Vector3(1, 1.0000033378601074, 1.0000033378601074)
})
blueLightButton.addComponentOrReplace(transform82)

const teleporterBase = new Entity('teleporterBase')
engine.addEntity(teleporterBase)
teleporterBase.setParent(_scene)
const transform83 = new Transform({
  position: new Vector3(8, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
teleporterBase.addComponentOrReplace(transform83)
const gltfShape7 = new GLTFShape("20e35437-2ae3-41f0-a99e-429b7c8c6bf2/Teleporter_01/Teleporter_01.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
teleporterBase.addComponentOrReplace(gltfShape7)

const blueLightButton2 = new Entity('blueLightButton2')
engine.addEntity(blueLightButton2)
blueLightButton2.setParent(_scene)
const transform84 = new Transform({
  position: new Vector3(6.5, 1.5, 4.293336391448975),
  rotation: new Quaternion(8.429366715745346e-8, 0.70710688829422, 0.7071067690849304, 2.2959934260356925e-14),
  scale: new Vector3(1.0000035762786865, 1.0000042915344238, 1.0000042915344238)
})
blueLightButton2.addComponentOrReplace(transform84)

const cyberpunkDoor2 = new Entity('cyberpunkDoor2')
engine.addEntity(cyberpunkDoor2)
cyberpunkDoor2.setParent(_scene)
const transform85 = new Transform({
  position: new Vector3(7, 0, 4.14238977432251),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
cyberpunkDoor2.addComponentOrReplace(transform85)

const externalLink2 = new Entity('externalLink2')
engine.addEntity(externalLink2)
externalLink2.setParent(_scene)
const transform86 = new Transform({
  position: new Vector3(15.680614471435547, 2.1547012329101562, 13.985254287719727),
  rotation: new Quaternion(0.5, 0.5, -0.5000001192092896, -0.5),
  scale: new Vector3(1.000010371208191, 1.0000102519989014, 1.0000101327896118)
})
externalLink2.addComponentOrReplace(transform86)

const externalLink3 = new Entity('externalLink3')
engine.addEntity(externalLink3)
externalLink3.setParent(_scene)
const transform87 = new Transform({
  position: new Vector3(15.67959213256836, 2.1547012329101562, 11.47982406616211),
  rotation: new Quaternion(0.5, 0.5, -0.5000001192092896, -0.5),
  scale: new Vector3(1.0000110864639282, 1.0000109672546387, 1.0000108480453491)
})
externalLink3.addComponentOrReplace(transform87)

const externalLink4 = new Entity('externalLink4')
engine.addEntity(externalLink4)
externalLink4.setParent(_scene)
const transform88 = new Transform({
  position: new Vector3(15.674972534179688, 2.1547012329101562, 8.973638534545898),
  rotation: new Quaternion(0.5, 0.5, -0.5000001192092896, -0.5),
  scale: new Vector3(1.0000118017196655, 1.000011682510376, 1.0000115633010864)
})
externalLink4.addComponentOrReplace(transform88)

const externalLink8 = new Entity('externalLink8')
engine.addEntity(externalLink8)
externalLink8.setParent(_scene)
const transform89 = new Transform({
  position: new Vector3(15.673690795898438, 2.1547012329101562, 6.453706741333008),
  rotation: new Quaternion(0.5, 0.5, -0.5000001192092896, -0.5),
  scale: new Vector3(1.0000125169754028, 1.0000123977661133, 1.0000122785568237)
})
externalLink8.addComponentOrReplace(transform89)

const ceilingLight5 = new Entity('ceilingLight5')
engine.addEntity(ceilingLight5)
ceilingLight5.setParent(_scene)
const transform90 = new Transform({
  position: new Vector3(14.809215545654297, 0, 6.249020099639893),
  rotation: new Quaternion(0, 0, 0, -1),
  scale: new Vector3(1, 1, 1)
})
ceilingLight5.addComponentOrReplace(transform90)

const ceilingLight6 = new Entity('ceilingLight6')
engine.addEntity(ceilingLight6)
ceilingLight6.setParent(_scene)
const transform91 = new Transform({
  position: new Vector3(14.809215545654297, 0, 8.749019622802734),
  rotation: new Quaternion(0, 0, 0, -1),
  scale: new Vector3(1, 1, 1)
})
ceilingLight6.addComponentOrReplace(transform91)

const ceilingLight7 = new Entity('ceilingLight7')
engine.addEntity(ceilingLight7)
ceilingLight7.setParent(_scene)
const transform92 = new Transform({
  position: new Vector3(14.809215545654297, 2.384185791015625e-7, 11.249019622802734),
  rotation: new Quaternion(0, 0, 0, -1),
  scale: new Vector3(1, 1, 1)
})
ceilingLight7.addComponentOrReplace(transform92)

const ceilingLight8 = new Entity('ceilingLight8')
engine.addEntity(ceilingLight8)
ceilingLight8.setParent(_scene)
const transform93 = new Transform({
  position: new Vector3(14.809215545654297, 9.5367431640625e-7, 13.749018669128418),
  rotation: new Quaternion(0, 0, 0, -1),
  scale: new Vector3(1, 1, 1)
})
ceilingLight8.addComponentOrReplace(transform93)

const imageComputerScreen3 = new Entity('imageComputerScreen3')
engine.addEntity(imageComputerScreen3)
imageComputerScreen3.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(14.857498168945312, 1.0068141222000122, 13.732067108154297),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000090599060059, 1, 1.0000090599060059)
})
imageComputerScreen3.addComponentOrReplace(transform94)

const keyboard2 = new Entity('keyboard2')
engine.addEntity(keyboard2)
keyboard2.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(14.566886901855469, 1.0032217502593994, 13.732065200805664),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000090599060059, 1, 1.0000090599060059)
})
keyboard2.addComponentOrReplace(transform95)

const uprightWorkTable3 = new Entity('uprightWorkTable3')
engine.addEntity(uprightWorkTable3)
uprightWorkTable3.setParent(_scene)
uprightWorkTable3.addComponentOrReplace(gltfShape4)
const transform96 = new Transform({
  position: new Vector3(14.777563095092773, 8.344650268554688e-7, 13.732067108154297),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000090599060059, 1, 1.0000090599060059)
})
uprightWorkTable3.addComponentOrReplace(transform96)

const keyboard6 = new Entity('keyboard6')
engine.addEntity(keyboard6)
keyboard6.setParent(_scene)
const transform97 = new Transform({
  position: new Vector3(14.566886901855469, 1.0032217502593994, 11.232067108154297),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000088214874268, 1, 1.0000088214874268)
})
keyboard6.addComponentOrReplace(transform97)

const imageComputerScreen6 = new Entity('imageComputerScreen6')
engine.addEntity(imageComputerScreen6)
imageComputerScreen6.setParent(_scene)
const transform98 = new Transform({
  position: new Vector3(14.857498168945312, 1.0068141222000122, 11.232067108154297),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000088214874268, 1, 1.0000088214874268)
})
imageComputerScreen6.addComponentOrReplace(transform98)

const uprightWorkTable6 = new Entity('uprightWorkTable6')
engine.addEntity(uprightWorkTable6)
uprightWorkTable6.setParent(_scene)
uprightWorkTable6.addComponentOrReplace(gltfShape4)
const transform99 = new Transform({
  position: new Vector3(14.777563095092773, 2.384185791015625e-7, 11.232067108154297),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000088214874268, 1, 1.0000088214874268)
})
uprightWorkTable6.addComponentOrReplace(transform99)

const keyboard7 = new Entity('keyboard7')
engine.addEntity(keyboard7)
keyboard7.setParent(_scene)
const transform100 = new Transform({
  position: new Vector3(14.566886901855469, 1.0032217502593994, 8.732067108154297),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000081062316895, 1, 1.0000081062316895)
})
keyboard7.addComponentOrReplace(transform100)

const imageComputerScreen7 = new Entity('imageComputerScreen7')
engine.addEntity(imageComputerScreen7)
imageComputerScreen7.setParent(_scene)
const transform101 = new Transform({
  position: new Vector3(14.857498168945312, 1.0068141222000122, 8.732067108154297),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000081062316895, 1, 1.0000081062316895)
})
imageComputerScreen7.addComponentOrReplace(transform101)

const uprightWorkTable7 = new Entity('uprightWorkTable7')
engine.addEntity(uprightWorkTable7)
uprightWorkTable7.setParent(_scene)
uprightWorkTable7.addComponentOrReplace(gltfShape4)
const transform102 = new Transform({
  position: new Vector3(14.777563095092773, 0, 8.732067108154297),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000081062316895, 1, 1.0000081062316895)
})
uprightWorkTable7.addComponentOrReplace(transform102)

const keyboard8 = new Entity('keyboard8')
engine.addEntity(keyboard8)
keyboard8.setParent(_scene)
const transform103 = new Transform({
  position: new Vector3(14.566886901855469, 1.0032217502593994, 6.232066631317139),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000073909759521, 1, 1.0000073909759521)
})
keyboard8.addComponentOrReplace(transform103)

const uprightWorkTable8 = new Entity('uprightWorkTable8')
engine.addEntity(uprightWorkTable8)
uprightWorkTable8.setParent(_scene)
uprightWorkTable8.addComponentOrReplace(gltfShape4)
const transform104 = new Transform({
  position: new Vector3(14.777563095092773, 0, 6.232067108154297),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000073909759521, 1, 1.0000073909759521)
})
uprightWorkTable8.addComponentOrReplace(transform104)

const imageComputerScreen8 = new Entity('imageComputerScreen8')
engine.addEntity(imageComputerScreen8)
imageComputerScreen8.setParent(_scene)
const transform105 = new Transform({
  position: new Vector3(14.857498168945312, 1.0068141222000122, 6.232066631317139),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000073909759521, 1, 1.0000073909759521)
})
imageComputerScreen8.addComponentOrReplace(transform105)

const fourSeatRow2 = new Entity('fourSeatRow2')
engine.addEntity(fourSeatRow2)
fourSeatRow2.setParent(_scene)
fourSeatRow2.addComponentOrReplace(gltfShape2)
const transform106 = new Transform({
  position: new Vector3(4.5, 4.295651912689209, 5),
  rotation: new Quaternion(2.005256905603438e-22, -3.725290298461914e-8, 4.891092227548655e-15, 1),
  scale: new Vector3(1.000004529953003, 1, 1.000004529953003)
})
fourSeatRow2.addComponentOrReplace(transform106)

const windowBlackLarge5 = new Entity('windowBlackLarge5')
engine.addEntity(windowBlackLarge5)
windowBlackLarge5.setParent(_scene)
windowBlackLarge5.addComponentOrReplace(gltfShape5)
const transform107 = new Transform({
  position: new Vector3(13, 4.2914347648620605, 9),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
windowBlackLarge5.addComponentOrReplace(transform107)

const windowBlackLarge6 = new Entity('windowBlackLarge6')
engine.addEntity(windowBlackLarge6)
windowBlackLarge6.setParent(_scene)
windowBlackLarge6.addComponentOrReplace(gltfShape5)
const transform108 = new Transform({
  position: new Vector3(10, 4.2914347648620605, 9),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
windowBlackLarge6.addComponentOrReplace(transform108)

const concreteWall22 = new Entity('concreteWall22')
engine.addEntity(concreteWall22)
concreteWall22.setParent(_scene)
concreteWall22.addComponentOrReplace(gltfShape)
const transform109 = new Transform({
  position: new Vector3(9.007379531860352, 4.2920451164245605, 4.009738445281982),
  rotation: new Quaternion(-1.1233005357044051e-14, 0.7071067690849304, -8.429368136830817e-8, 0.7071068286895752),
  scale: new Vector3(0.7719658613204956, 1, 1)
})
concreteWall22.addComponentOrReplace(transform109)

const dockColumn = new Entity('dockColumn')
engine.addEntity(dockColumn)
dockColumn.setParent(_scene)
const transform110 = new Transform({
  position: new Vector3(9.276435852050781, 0, 0.6532901525497437),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1.4010181427001953, 1)
})
dockColumn.addComponentOrReplace(transform110)
const gltfShape8 = new GLTFShape("2c4e03b5-8658-4e59-940e-29a99a96ae42/Dock_Column_01/Dock_Column_01.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
dockColumn.addComponentOrReplace(gltfShape8)

const dockColumn2 = new Entity('dockColumn2')
engine.addEntity(dockColumn2)
dockColumn2.setParent(_scene)
dockColumn2.addComponentOrReplace(gltfShape8)
const transform111 = new Transform({
  position: new Vector3(15.996710777282715, 0, 0.6530817747116089),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1.4010181427001953, 1)
})
dockColumn2.addComponentOrReplace(transform111)

const fullCurvedBarrier = new Entity('fullCurvedBarrier')
engine.addEntity(fullCurvedBarrier)
fullCurvedBarrier.setParent(_scene)
const transform112 = new Transform({
  position: new Vector3(12.318131446838379, 4.285194396972656, 0.12315303087234497),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fullCurvedBarrier.addComponentOrReplace(transform112)
const gltfShape9 = new GLTFShape("368746f0-d50f-4228-88f8-bd199240b71a/Fence_Straight_02/Fence_Straight_02.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
fullCurvedBarrier.addComponentOrReplace(gltfShape9)

const hallwayDoorOpen = new Entity('hallwayDoorOpen')
engine.addEntity(hallwayDoorOpen)
hallwayDoorOpen.setParent(_scene)
const transform113 = new Transform({
  position: new Vector3(9, 4.294008255004883, 7),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(0.5000014901161194, 1.0528523921966553, 1.0000029802322388)
})
hallwayDoorOpen.addComponentOrReplace(transform113)
const gltfShape10 = new GLTFShape("1c2952f6-41d1-49e9-a6a0-78f7868b4332/Hallway_Module_Door_02/Hallway_Module_Door_02.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
hallwayDoorOpen.addComponentOrReplace(gltfShape10)

const concreteWall20 = new Entity('concreteWall20')
engine.addEntity(concreteWall20)
concreteWall20.setParent(_scene)
concreteWall20.addComponentOrReplace(gltfShape)
const transform114 = new Transform({
  position: new Vector3(14.9998140335083, 4.2920451164245605, 9),
  rotation: new Quaternion(1.1022388920643375e-14, -1, 1.1920926823449918e-7, -5.960464477539063e-8),
  scale: new Vector3(0.498678058385849, 1, 1)
})
concreteWall20.addComponentOrReplace(transform114)

const concreteWall21 = new Entity('concreteWall21')
engine.addEntity(concreteWall21)
concreteWall21.setParent(_scene)
concreteWall21.addComponentOrReplace(gltfShape)
const transform115 = new Transform({
  position: new Vector3(12, 4.2920451164245605, 9),
  rotation: new Quaternion(1.1022388920643375e-14, -1, 1.1920926823449918e-7, -5.960464477539063e-8),
  scale: new Vector3(0.498678058385849, 1, 1)
})
concreteWall21.addComponentOrReplace(transform115)

const concreteWall23 = new Entity('concreteWall23')
engine.addEntity(concreteWall23)
concreteWall23.setParent(_scene)
concreteWall23.addComponentOrReplace(gltfShape)
const transform116 = new Transform({
  position: new Vector3(9, 4.2920451164245605, 9),
  rotation: new Quaternion(1.1022388920643375e-14, -1, 1.1920926823449918e-7, -5.960464477539063e-8),
  scale: new Vector3(0.498678058385849, 1, 1)
})
concreteWall23.addComponentOrReplace(transform116)

const concreteWall24 = new Entity('concreteWall24')
engine.addEntity(concreteWall24)
concreteWall24.setParent(_scene)
concreteWall24.addComponentOrReplace(gltfShape)
const transform117 = new Transform({
  position: new Vector3(8.701178550720215, 4.2920451164245605, 9.299775123596191),
  rotation: new Quaternion(6.88579446723504e-16, -0.70710688829422, 8.429368847373553e-8, 0.7071067690849304),
  scale: new Vector3(0.4352618157863617, 1, 1.0000019073486328)
})
concreteWall24.addComponentOrReplace(transform117)

const windowBlackLarge7 = new Entity('windowBlackLarge7')
engine.addEntity(windowBlackLarge7)
windowBlackLarge7.setParent(_scene)
windowBlackLarge7.addComponentOrReplace(gltfShape5)
const transform118 = new Transform({
  position: new Vector3(1, 4.2914347648620605, 4),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
windowBlackLarge7.addComponentOrReplace(transform118)

const windowBlackLarge8 = new Entity('windowBlackLarge8')
engine.addEntity(windowBlackLarge8)
windowBlackLarge8.setParent(_scene)
windowBlackLarge8.addComponentOrReplace(gltfShape5)
const transform119 = new Transform({
  position: new Vector3(4, 4.2914347648620605, 4),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
windowBlackLarge8.addComponentOrReplace(transform119)

const concreteWall19 = new Entity('concreteWall19')
engine.addEntity(concreteWall19)
concreteWall19.setParent(_scene)
concreteWall19.addComponentOrReplace(gltfShape)
const transform120 = new Transform({
  position: new Vector3(5.992884635925293, 4.2920451164245605, 4.009491920471191),
  rotation: new Quaternion(1.1022388920643375e-14, -1, 1.1920926823449918e-7, -5.960464477539063e-8),
  scale: new Vector3(1.4751282930374146, 1, 1)
})
concreteWall19.addComponentOrReplace(transform120)

const concreteWall25 = new Entity('concreteWall25')
engine.addEntity(concreteWall25)
concreteWall25.setParent(_scene)
concreteWall25.addComponentOrReplace(gltfShape)
const transform121 = new Transform({
  position: new Vector3(3, 4.2920451164245605, 4),
  rotation: new Quaternion(1.1022388920643375e-14, -1, 1.1920926823449918e-7, -5.960464477539063e-8),
  scale: new Vector3(0.498678058385849, 1, 1)
})
concreteWall25.addComponentOrReplace(transform121)

const concreteWall26 = new Entity('concreteWall26')
engine.addEntity(concreteWall26)
concreteWall26.setParent(_scene)
concreteWall26.addComponentOrReplace(gltfShape)
const transform122 = new Transform({
  position: new Vector3(0, 4.2920451164245605, 4),
  rotation: new Quaternion(1.1022388920643375e-14, -1, 1.1920926823449918e-7, -5.960464477539063e-8),
  scale: new Vector3(0.498678058385849, 1, 1)
})
concreteWall26.addComponentOrReplace(transform122)

const ballDroid = new Entity('ballDroid')
engine.addEntity(ballDroid)
ballDroid.setParent(_scene)
const transform123 = new Transform({
  position: new Vector3(1.5, 5.5, 5.5),
  rotation: new Quaternion(2.2097539788269016e-16, -0.3826834261417389, 4.5619412247788205e-8, -0.9238795638084412),
  scale: new Vector3(1, 1, 1)
})
ballDroid.addComponentOrReplace(transform123)
const gltfShape11 = new GLTFShape("53a5cc56-9817-4556-a172-bc1a4256610d/Droid_01/Droid_01.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
ballDroid.addComponentOrReplace(gltfShape11)

const curvedGreyDrawers = new Entity('curvedGreyDrawers')
engine.addEntity(curvedGreyDrawers)
curvedGreyDrawers.setParent(_scene)
const transform124 = new Transform({
  position: new Vector3(15.28003978729248, 4.2653422355651855, 10.5),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000028610229492, 1, 1.0000028610229492)
})
curvedGreyDrawers.addComponentOrReplace(transform124)
const gltfShape12 = new GLTFShape("19fc7609-5ce9-44de-a8e9-9823dd223f74/Drawer_03/Drawer_03.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
curvedGreyDrawers.addComponentOrReplace(gltfShape12)

const fullCurvedBarrier2 = new Entity('fullCurvedBarrier2')
engine.addEntity(fullCurvedBarrier2)
fullCurvedBarrier2.setParent(_scene)
fullCurvedBarrier2.addComponentOrReplace(gltfShape9)
const transform125 = new Transform({
  position: new Vector3(15.697904586791992, 4.285194396972656, 0.12484326958656311),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fullCurvedBarrier2.addComponentOrReplace(transform125)

const fullCurvedBarrier4 = new Entity('fullCurvedBarrier4')
engine.addEntity(fullCurvedBarrier4)
fullCurvedBarrier4.setParent(_scene)
fullCurvedBarrier4.addComponentOrReplace(gltfShape9)
const transform126 = new Transform({
  position: new Vector3(15.886433601379395, 4.285194396972656, 0.1467992067337036),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.1971242427825928, 1, 1.0000040531158447)
})
fullCurvedBarrier4.addComponentOrReplace(transform126)

const fullCurvedBarrier5 = new Entity('fullCurvedBarrier5')
engine.addEntity(fullCurvedBarrier5)
fullCurvedBarrier5.setParent(_scene)
fullCurvedBarrier5.addComponentOrReplace(gltfShape9)
const transform127 = new Transform({
  position: new Vector3(9.114712715148926, 4.285194396972656, 0.1485716700553894),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.2571959495544434, 1, 1.0000035762786865)
})
fullCurvedBarrier5.addComponentOrReplace(transform127)

const tieredDesk = new Entity('tieredDesk')
engine.addEntity(tieredDesk)
tieredDesk.setParent(_scene)
const transform128 = new Transform({
  position: new Vector3(15.537266731262207, 4.2718706130981445, 12.5),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000014305114746, 1, 1.0000014305114746)
})
tieredDesk.addComponentOrReplace(transform128)
const gltfShape13 = new GLTFShape("337f9d3d-cd76-4172-9f54-16c64a348734/Desk_01/Desk_01.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
tieredDesk.addComponentOrReplace(gltfShape13)

const foldingChair = new Entity('foldingChair')
engine.addEntity(foldingChair)
foldingChair.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(14.462732315063477, 4.299808502197266, 12.5),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000007152557373, 1, 1.0000007152557373)
})
foldingChair.addComponentOrReplace(transform129)
const gltfShape14 = new GLTFShape("e31c1ffb-0712-44f5-9e55-b74a73d077d4/Chair_01/Chair_01.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
foldingChair.addComponentOrReplace(gltfShape14)

const computerThin = new Entity('computerThin')
engine.addEntity(computerThin)
computerThin.setParent(_scene)
const transform130 = new Transform({
  position: new Vector3(15.348167419433594, 4.2722320556640625, 14.5),
  rotation: new Quaternion(9.753302749178306e-16, -0.7071068286895752, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1.0000007152557373, 1, 1.0000007152557373)
})
computerThin.addComponentOrReplace(transform130)
const gltfShape15 = new GLTFShape("8c1def81-f26c-4514-9423-4e621026a627/Computer_01/Computer_01.glb")
gltfShape15.withCollisions = true
gltfShape15.isPointerBlocker = true
gltfShape15.visible = true
computerThin.addComponentOrReplace(gltfShape15)

const nftPictureFrame = new Entity('nftPictureFrame')
engine.addEntity(nftPictureFrame)
nftPictureFrame.setParent(_scene)
const transform131 = new Transform({
  position: new Vector3(10, 6.5, 15.677427291870117),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame.addComponentOrReplace(transform131)

const nftPictureFrame2 = new Entity('nftPictureFrame2')
engine.addEntity(nftPictureFrame2)
nftPictureFrame2.setParent(_scene)
const transform132 = new Transform({
  position: new Vector3(12, 6.5, 15.677427291870117),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame2.addComponentOrReplace(transform132)

const nftPictureFrame3 = new Entity('nftPictureFrame3')
engine.addEntity(nftPictureFrame3)
nftPictureFrame3.setParent(_scene)
const transform133 = new Transform({
  position: new Vector3(14, 6.5, 15.677427291870117),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame3.addComponentOrReplace(transform133)

const videoStream = new Entity('videoStream')
engine.addEntity(videoStream)
videoStream.setParent(_scene)
const transform134 = new Transform({
  position: new Vector3(4, 1.5, 15.704179763793945),
  rotation: new Quaternion(7.14659654696935e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1, 1, 1)
})
videoStream.addComponentOrReplace(transform134)

const videoStream2 = new Entity('videoStream2')
engine.addEntity(videoStream2)
videoStream2.setParent(_scene)
const transform135 = new Transform({
  position: new Vector3(12, 1.5, 15.698486328125),
  rotation: new Quaternion(8.891088853926841e-15, -1, 1.1920928244535389e-7, -2.2351741790771484e-8),
  scale: new Vector3(1, 1, 1)
})
videoStream2.addComponentOrReplace(transform135)

const dockColumn3 = new Entity('dockColumn3')
engine.addEntity(dockColumn3)
dockColumn3.setParent(_scene)
dockColumn3.addComponentOrReplace(gltfShape8)
const transform136 = new Transform({
  position: new Vector3(15.99545669555664, 4.262569904327393, 4.369766712188721),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1.3571109771728516, 1)
})
dockColumn3.addComponentOrReplace(transform136)

const nftPictureFrame4 = new Entity('nftPictureFrame4')
engine.addEntity(nftPictureFrame4)
nftPictureFrame4.setParent(_scene)
const transform137 = new Transform({
  position: new Vector3(0.32236814498901367, 6.5, 8.5),
  rotation: new Quaternion(4.127578846475997e-15, -0.7071068286895752, 8.429370268459024e-8, -0.7071067690849304),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame4.addComponentOrReplace(transform137)

const underConstructionSign = new Entity('underConstructionSign')
engine.addEntity(underConstructionSign)
underConstructionSign.setParent(_scene)
const transform138 = new Transform({
  position: new Vector3(9.5, 0, 3.917396068572998),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000011920928955, 1, 1.0000011920928955)
})
underConstructionSign.addComponentOrReplace(transform138)
const gltfShape16 = new GLTFShape("552e9281-df22-462d-9125-3c66853505d0/ConstructionSign_01/ConstructionSign_01.glb")
gltfShape16.withCollisions = true
gltfShape16.isPointerBlocker = true
gltfShape16.visible = true
underConstructionSign.addComponentOrReplace(gltfShape16)

const umbrellaTable = new Entity('umbrellaTable')
engine.addEntity(umbrellaTable)
umbrellaTable.setParent(_scene)
const transform139 = new Transform({
  position: new Vector3(12.5, 4.252213954925537, 2.5),
  rotation: new Quaternion(1.9792379591683637e-15, -0.7071067690849304, 8.429368847373553e-8, -0.7071068286895752),
  scale: new Vector3(1, 1, 1)
})
umbrellaTable.addComponentOrReplace(transform139)
const gltfShape17 = new GLTFShape("8bbdfe3a-8a61-4e93-9809-1d5e8d92f17a/TableBar_01/TableBar_01.glb")
gltfShape17.withCollisions = true
gltfShape17.isPointerBlocker = true
gltfShape17.visible = true
umbrellaTable.addComponentOrReplace(gltfShape17)

const outdoorChair = new Entity('outdoorChair')
engine.addEntity(outdoorChair)
outdoorChair.setParent(_scene)
const transform140 = new Transform({
  position: new Vector3(14, 4.285223484039307, 2.5),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000007152557373, 1, 1.0000007152557373)
})
outdoorChair.addComponentOrReplace(transform140)
const gltfShape18 = new GLTFShape("8707b21f-e3a0-4d8b-8da0-60d8927de229/Chair_07/Chair_07.glb")
gltfShape18.withCollisions = true
gltfShape18.isPointerBlocker = true
gltfShape18.visible = true
outdoorChair.addComponentOrReplace(gltfShape18)

const outdoorChair2 = new Entity('outdoorChair2')
engine.addEntity(outdoorChair2)
outdoorChair2.setParent(_scene)
outdoorChair2.addComponentOrReplace(gltfShape18)
const transform141 = new Transform({
  position: new Vector3(11, 4.285223484039307, 2.5),
  rotation: new Quaternion(-4.127578846475997e-15, -0.7071068286895752, 8.429370268459024e-8, -0.7071068286895752),
  scale: new Vector3(1.0000011920928955, 1, 1.0000011920928955)
})
outdoorChair2.addComponentOrReplace(transform141)

const solarPanel = new Entity('solarPanel')
engine.addEntity(solarPanel)
solarPanel.setParent(_scene)
const transform142 = new Transform({
  position: new Vector3(1.5, 0, 1),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
solarPanel.addComponentOrReplace(transform142)
const gltfShape19 = new GLTFShape("fc1458e2-d886-4901-b3d2-21d003ea73c4/SolarPanel_01/SolarPanel_01.glb")
gltfShape19.withCollisions = true
gltfShape19.isPointerBlocker = true
gltfShape19.visible = true
solarPanel.addComponentOrReplace(gltfShape19)

const solarPanel2 = new Entity('solarPanel2')
engine.addEntity(solarPanel2)
solarPanel2.setParent(_scene)
solarPanel2.addComponentOrReplace(gltfShape19)
const transform143 = new Transform({
  position: new Vector3(3.5, 0, 1),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
solarPanel2.addComponentOrReplace(transform143)

const solarPanel3 = new Entity('solarPanel3')
engine.addEntity(solarPanel3)
solarPanel3.setParent(_scene)
solarPanel3.addComponentOrReplace(gltfShape19)
const transform144 = new Transform({
  position: new Vector3(5.5, 0, 1),
  rotation: new Quaternion(-5.837277581059123e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
solarPanel3.addComponentOrReplace(transform144)

const microwave = new Entity('microwave')
engine.addEntity(microwave)
microwave.setParent(_scene)
const transform145 = new Transform({
  position: new Vector3(1.1905369758605957, 5.255931377410889, 13.000642776489258),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429370268459024e-8, 0.7071068286895752),
  scale: new Vector3(1.0000009536743164, 1, 1.0000009536743164)
})
microwave.addComponentOrReplace(transform145)

const qrScifiFrame = new Entity('qrScifiFrame')
engine.addEntity(qrScifiFrame)
qrScifiFrame.setParent(_scene)
const transform146 = new Transform({
  position: new Vector3(7.5, 5.856284141540527, 4.346601486206055),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
qrScifiFrame.addComponentOrReplace(transform146)

const yellowDinnerTable2 = new Entity('yellowDinnerTable2')
engine.addEntity(yellowDinnerTable2)
yellowDinnerTable2.setParent(_scene)
const gltfShape20 = new GLTFShape("87383b74-7a88-4722-b298-fd1fb0444a77/TableSciFi_02/TableSciFi_02.glb")
gltfShape20.withCollisions = true
gltfShape20.isPointerBlocker = true
gltfShape20.visible = true
yellowDinnerTable2.addComponentOrReplace(gltfShape20)
const transform147 = new Transform({
  position: new Vector3(0.9745383262634277, 4.289841651916504, 12.981098175048828),
  rotation: new Quaternion(-1.5394153601527394e-15, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000009536743164, 1, 1.0000009536743164)
})
yellowDinnerTable2.addComponentOrReplace(transform147)

const slushieMachine = new Entity('slushieMachine')
engine.addEntity(slushieMachine)
slushieMachine.setParent(_scene)
const transform148 = new Transform({
  position: new Vector3(1.2604384422302246, 5.232807159423828, 11.999357223510742),
  rotation: new Quaternion(-4.127578846475997e-15, 0.7071068286895752, -8.429370268459024e-8, 0.7071068286895752),
  scale: new Vector3(1.0000009536743164, 1, 1.0000009536743164)
})
slushieMachine.addComponentOrReplace(transform148)

const fourSquareFloorPanel41 = new Entity('fourSquareFloorPanel41')
engine.addEntity(fourSquareFloorPanel41)
fourSquareFloorPanel41.setParent(_scene)
fourSquareFloorPanel41.addComponentOrReplace(gltfShape6)
const transform149 = new Transform({
  position: new Vector3(16, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel41.addComponentOrReplace(transform149)

const fourSquareFloorPanel42 = new Entity('fourSquareFloorPanel42')
engine.addEntity(fourSquareFloorPanel42)
fourSquareFloorPanel42.setParent(_scene)
fourSquareFloorPanel42.addComponentOrReplace(gltfShape6)
const transform150 = new Transform({
  position: new Vector3(14, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel42.addComponentOrReplace(transform150)

const fourSquareFloorPanel43 = new Entity('fourSquareFloorPanel43')
engine.addEntity(fourSquareFloorPanel43)
fourSquareFloorPanel43.setParent(_scene)
fourSquareFloorPanel43.addComponentOrReplace(gltfShape6)
const transform151 = new Transform({
  position: new Vector3(12, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel43.addComponentOrReplace(transform151)

const fourSquareFloorPanel44 = new Entity('fourSquareFloorPanel44')
engine.addEntity(fourSquareFloorPanel44)
fourSquareFloorPanel44.setParent(_scene)
fourSquareFloorPanel44.addComponentOrReplace(gltfShape6)
const transform152 = new Transform({
  position: new Vector3(10, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel44.addComponentOrReplace(transform152)

const fourSquareFloorPanel45 = new Entity('fourSquareFloorPanel45')
engine.addEntity(fourSquareFloorPanel45)
fourSquareFloorPanel45.setParent(_scene)
fourSquareFloorPanel45.addComponentOrReplace(gltfShape6)
const transform153 = new Transform({
  position: new Vector3(8, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel45.addComponentOrReplace(transform153)

const fourSquareFloorPanel46 = new Entity('fourSquareFloorPanel46')
engine.addEntity(fourSquareFloorPanel46)
fourSquareFloorPanel46.setParent(_scene)
fourSquareFloorPanel46.addComponentOrReplace(gltfShape6)
const transform154 = new Transform({
  position: new Vector3(6, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel46.addComponentOrReplace(transform154)

const fourSquareFloorPanel47 = new Entity('fourSquareFloorPanel47')
engine.addEntity(fourSquareFloorPanel47)
fourSquareFloorPanel47.setParent(_scene)
fourSquareFloorPanel47.addComponentOrReplace(gltfShape6)
const transform155 = new Transform({
  position: new Vector3(4, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel47.addComponentOrReplace(transform155)

const fourSquareFloorPanel48 = new Entity('fourSquareFloorPanel48')
engine.addEntity(fourSquareFloorPanel48)
fourSquareFloorPanel48.setParent(_scene)
fourSquareFloorPanel48.addComponentOrReplace(gltfShape6)
const transform156 = new Transform({
  position: new Vector3(2, 0, 6),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fourSquareFloorPanel48.addComponentOrReplace(transform156)

const concreteWall = new Entity('concreteWall')
engine.addEntity(concreteWall)
concreteWall.setParent(_scene)
concreteWall.addComponentOrReplace(gltfShape)
const transform157 = new Transform({
  position: new Vector3(16, 0, 4),
  rotation: new Quaternion(8.214510275879154e-15, -0.7071068286895752, 8.429370268459024e-8, -0.7071068286895752),
  scale: new Vector3(5.950463771820068, 1, 1.0000032186508179)
})
concreteWall.addComponentOrReplace(transform157)

const concreteWall6 = new Entity('concreteWall6')
engine.addEntity(concreteWall6)
concreteWall6.setParent(_scene)
concreteWall6.addComponentOrReplace(gltfShape)
const transform158 = new Transform({
  position: new Vector3(4.099030494689941, 0, 15.709844589233398),
  rotation: new Quaternion(1.4617049365057803e-14, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(5.9504828453063965, 2.0950589179992676, 1.0000020265579224)
})
concreteWall6.addComponentOrReplace(transform158)

const concreteWall7 = new Entity('concreteWall7')
engine.addEntity(concreteWall7)
concreteWall7.setParent(_scene)
concreteWall7.addComponentOrReplace(gltfShape)
const transform159 = new Transform({
  position: new Vector3(0.09903037548065186, 0, 15.709844589233398),
  rotation: new Quaternion(1.4617049365057803e-14, -1, 1.1920927533992653e-7, 0),
  scale: new Vector3(5.9504828453063965, 2.1058597564697266, 1.0000020265579224)
})
concreteWall7.addComponentOrReplace(transform159)

const concreteWall8 = new Entity('concreteWall8')
engine.addEntity(concreteWall8)
concreteWall8.setParent(_scene)
concreteWall8.addComponentOrReplace(gltfShape)
const transform160 = new Transform({
  position: new Vector3(0.2936229705810547, 0, 4.107706069946289),
  rotation: new Quaternion(8.214510275879154e-15, -0.7071068286895752, 8.429370268459024e-8, -0.7071068286895752),
  scale: new Vector3(5.950478553771973, 2.0974276065826416, 1.0000027418136597)
})
concreteWall8.addComponentOrReplace(transform160)

const greenLightButton = new Entity('greenLightButton')
engine.addEntity(greenLightButton)
greenLightButton.setParent(_scene)
const transform161 = new Transform({
  position: new Vector3(7.5, 2, 15.727867126464844),
  rotation: new Quaternion(-0.7071068286895752, 2.3709623216697446e-15, 8.429369557916289e-8, 0.7071067690849304),
  scale: new Vector3(1, 1.0000005960464478, 1.0000005960464478)
})
greenLightButton.addComponentOrReplace(transform161)

const concreteWall9 = new Entity('concreteWall9')
engine.addEntity(concreteWall9)
concreteWall9.setParent(_scene)
concreteWall9.addComponentOrReplace(gltfShape)
const transform162 = new Transform({
  position: new Vector3(0, 4, 16),
  rotation: new Quaternion(8.429370268459024e-8, -0.7071067690849304, 0.70710688829422, 1.8266401032810548e-15),
  scale: new Vector3(3.3709964752197266, 1.000002384185791, 1.0000046491622925)
})
concreteWall9.addComponentOrReplace(transform162)

const concreteWall10 = new Entity('concreteWall10')
engine.addEntity(concreteWall10)
concreteWall10.setParent(_scene)
concreteWall10.addComponentOrReplace(gltfShape)
const transform163 = new Transform({
  position: new Vector3(9.261968612670898, 4, 16),
  rotation: new Quaternion(8.429370268459024e-8, -0.7071067690849304, 0.70710688829422, 1.8266401032810548e-15),
  scale: new Vector3(3.3709986209869385, 1.5000050067901611, 1.0000053644180298)
})
concreteWall10.addComponentOrReplace(transform163)

const concreteWall11 = new Entity('concreteWall11')
engine.addEntity(concreteWall11)
concreteWall11.setParent(_scene)
concreteWall11.addComponentOrReplace(gltfShape)
const transform164 = new Transform({
  position: new Vector3(0, 4, 12.490670204162598),
  rotation: new Quaternion(8.429370268459024e-8, -0.7071067690849304, 0.70710688829422, 1.8266401032810548e-15),
  scale: new Vector3(4.702064037322998, 2.121631383895874, 1.0000067949295044)
})
concreteWall11.addComponentOrReplace(transform164)

const concreteWall14 = new Entity('concreteWall14')
engine.addEntity(concreteWall14)
concreteWall14.setParent(_scene)
concreteWall14.addComponentOrReplace(gltfShape)
const transform165 = new Transform({
  position: new Vector3(9.01578140258789, 4, 11.795093536376953),
  rotation: new Quaternion(8.429370268459024e-8, -0.7071067690849304, 0.70710688829422, 1.8266401032810548e-15),
  scale: new Vector3(3.493596076965332, 2.949518918991089, 1.0000089406967163)
})
concreteWall14.addComponentOrReplace(transform165)

const concreteWall15 = new Entity('concreteWall15')
engine.addEntity(concreteWall15)
concreteWall15.setParent(_scene)
concreteWall15.addComponentOrReplace(gltfShape)
const transform166 = new Transform({
  position: new Vector3(16, 4.2920451164245605, 9),
  rotation: new Quaternion(-6.885792879048264e-16, 0.7071067690849304, -8.429368847373553e-8, 0.70710688829422),
  scale: new Vector3(3.4856207370758057, 1, 1.0000028610229492)
})
concreteWall15.addComponentOrReplace(transform166)

const videoStream3 = new Entity('videoStream3')
engine.addEntity(videoStream3)
videoStream3.setParent(_scene)
const transform167 = new Transform({
  position: new Vector3(4, 5.5, 15.704179763793945),
  rotation: new Quaternion(7.14659654696935e-15, -1, 1.1920928244535389e-7, -3.725290298461914e-8),
  scale: new Vector3(1.5, 1.5, 1)
})
videoStream3.addComponentOrReplace(transform167)

const redLightButton = new Entity('redLightButton')
engine.addEntity(redLightButton)
redLightButton.setParent(_scene)
const transform168 = new Transform({
  position: new Vector3(8.5, 2, 15.727867126464844),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1, 1.0000014305114746, 1.0000014305114746)
})
redLightButton.addComponentOrReplace(transform168)

const greenLightButton3 = new Entity('greenLightButton3')
engine.addEntity(greenLightButton3)
greenLightButton3.setParent(_scene)
const transform169 = new Transform({
  position: new Vector3(7.5, 6, 15.727867126464844),
  rotation: new Quaternion(-0.7071068286895752, 2.3709623216697446e-15, 8.429369557916289e-8, 0.7071067690849304),
  scale: new Vector3(1, 1.0000005960464478, 1.0000005960464478)
})
greenLightButton3.addComponentOrReplace(transform169)

const redLightButton2 = new Entity('redLightButton2')
engine.addEntity(redLightButton2)
redLightButton2.setParent(_scene)
const transform170 = new Transform({
  position: new Vector3(8.5, 6, 15.727867126464844),
  rotation: new Quaternion(-0.7071068286895752, 1.5394153601527394e-15, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1, 1.000002145767212, 1.000002145767212)
})
redLightButton2.addComponentOrReplace(transform170)

const smoothCactus = new Entity('smoothCactus')
engine.addEntity(smoothCactus)
smoothCactus.setParent(_scene)
const transform171 = new Transform({
  position: new Vector3(2.7793736457824707, 0, 2.1822197437286377),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
smoothCactus.addComponentOrReplace(transform171)
const gltfShape21 = new GLTFShape("c94a39e6-cd04-49c0-8687-a547f4d673ba/PlantSF_03/PlantSF_03.glb")
gltfShape21.withCollisions = true
gltfShape21.isPointerBlocker = true
gltfShape21.visible = true
smoothCactus.addComponentOrReplace(gltfShape21)

const yellowBuds = new Entity('yellowBuds')
engine.addEntity(yellowBuds)
yellowBuds.setParent(_scene)
const transform172 = new Transform({
  position: new Vector3(5.038833141326904, 0, 3.3980720043182373),
  rotation: new Quaternion(-1.0446245580250473e-14, 0.9570239782333374, -1.1408612721197642e-7, 0.2900089919567108),
  scale: new Vector3(1.0000017881393433, 1, 1.0000017881393433)
})
yellowBuds.addComponentOrReplace(transform172)
const gltfShape22 = new GLTFShape("f18f23b1-dce3-426b-8039-3fd7a5100862/PlantSF_02/PlantSF_02.glb")
gltfShape22.withCollisions = true
gltfShape22.isPointerBlocker = true
gltfShape22.visible = true
yellowBuds.addComponentOrReplace(gltfShape22)

const tubularFronds = new Entity('tubularFronds')
engine.addEntity(tubularFronds)
tubularFronds.setParent(_scene)
const transform173 = new Transform({
  position: new Vector3(5.794930458068848, 0.17134499549865723, 2.3572263717651367),
  rotation: new Quaternion(1.897970103022055e-14, -0.8874313235282898, 1.0579006470834429e-7, -0.4609401226043701),
  scale: new Vector3(1.0000033378601074, 1, 1.0000033378601074)
})
tubularFronds.addComponentOrReplace(transform173)
const gltfShape23 = new GLTFShape("d06e22f7-0816-4e5e-98ff-50e87b8e78f3/PlantSF_09/PlantSF_09.glb")
gltfShape23.withCollisions = true
gltfShape23.isPointerBlocker = true
gltfShape23.visible = true
tubularFronds.addComponentOrReplace(gltfShape23)

const purplePalm = new Entity('purplePalm')
engine.addEntity(purplePalm)
purplePalm.setParent(_scene)
const transform174 = new Transform({
  position: new Vector3(3.4364941120147705, 0.22618138790130615, 2.871554136276245),
  rotation: new Quaternion(-4.4247167338233844e-15, 0.8868474960327148, -1.0572043862566716e-7, -0.4620623290538788),
  scale: new Vector3(1.0000020265579224, 1, 1.0000020265579224)
})
purplePalm.addComponentOrReplace(transform174)
const gltfShape24 = new GLTFShape("c49b66db-8764-4d37-b0d3-746c8b6eba7f/PlantSF_01/PlantSF_01.glb")
gltfShape24.withCollisions = true
gltfShape24.isPointerBlocker = true
gltfShape24.visible = true
purplePalm.addComponentOrReplace(gltfShape24)

const purpleFuschia = new Entity('purpleFuschia')
engine.addEntity(purpleFuschia)
purpleFuschia.setParent(_scene)
const transform175 = new Transform({
  position: new Vector3(1.310968279838562, 0, 2.6506454944610596),
  rotation: new Quaternion(-1.0175588775100672e-17, 0.8819213509559631, -1.0513321058169822e-7, 0.4713967442512512),
  scale: new Vector3(1.0000033378601074, 1, 1.0000033378601074)
})
purpleFuschia.addComponentOrReplace(transform175)
const gltfShape25 = new GLTFShape("041975a3-5bca-4119-aad5-100d97e3d5b1/PlantSF_12/PlantSF_12.glb")
gltfShape25.withCollisions = true
gltfShape25.isPointerBlocker = true
gltfShape25.visible = true
purpleFuschia.addComponentOrReplace(gltfShape25)

const fernRose = new Entity('fernRose')
engine.addEntity(fernRose)
fernRose.setParent(_scene)
const transform176 = new Transform({
  position: new Vector3(2.2723467350006104, 0.09338295459747314, 3.224839210510254),
  rotation: new Quaternion(5.788493989011432e-15, 0.9850516319274902, -1.1742728389663171e-7, -0.1722595989704132),
  scale: new Vector3(1.0000014305114746, 1, 1.0000014305114746)
})
fernRose.addComponentOrReplace(transform176)
const gltfShape26 = new GLTFShape("9e363828-8951-48a6-a953-027ee544615b/PlantSF_05/PlantSF_05.glb")
gltfShape26.withCollisions = true
gltfShape26.isPointerBlocker = true
gltfShape26.visible = true
fernRose.addComponentOrReplace(gltfShape26)

const cactusWand = new Entity('cactusWand')
engine.addEntity(cactusWand)
cactusWand.setParent(_scene)
const transform177 = new Transform({
  position: new Vector3(1.3732829093933105, 0.17268109321594238, 1.4479165077209473),
  rotation: new Quaternion(-0.0980171412229538, 0, 1.1684551992630077e-8, 0.9951847195625305),
  scale: new Vector3(1, 0.9999999403953552, 0.9999999403953552)
})
cactusWand.addComponentOrReplace(transform177)
const gltfShape27 = new GLTFShape("5f25759e-dd1b-4294-9bc7-d8e66c198e9f/PlantSF_07/PlantSF_07.glb")
gltfShape27.withCollisions = true
gltfShape27.isPointerBlocker = true
gltfShape27.visible = true
cactusWand.addComponentOrReplace(gltfShape27)

const dirtPatch = new Entity('dirtPatch')
engine.addEntity(dirtPatch)
dirtPatch.setParent(_scene)
const transform178 = new Transform({
  position: new Vector3(3, 0, 3),
  rotation: new Quaternion(-2.220446049250313e-16, 0.3826834559440613, -4.561941935321556e-8, 0.9238795638084412),
  scale: new Vector3(1, 1, 1)
})
dirtPatch.addComponentOrReplace(transform178)
const gltfShape28 = new GLTFShape("8c5540f1-c30c-4a57-91e9-c4855248042d/Dirt_04/Dirt_04.glb")
gltfShape28.withCollisions = true
gltfShape28.isPointerBlocker = true
gltfShape28.visible = true
dirtPatch.addComponentOrReplace(gltfShape28)

const dirtMound = new Entity('dirtMound')
engine.addEntity(dirtMound)
dirtMound.setParent(_scene)
const transform179 = new Transform({
  position: new Vector3(1.5, 0, 2.5),
  rotation: new Quaternion(-6.438242374938365e-16, 0.6343933343887329, -7.56255715828047e-8, 0.7730104923248291),
  scale: new Vector3(1.0000014305114746, 1, 1.0000014305114746)
})
dirtMound.addComponentOrReplace(transform179)
const gltfShape29 = new GLTFShape("82a8f521-ea30-4fba-b91f-840b2658779d/Dirt_03/Dirt_03.glb")
gltfShape29.withCollisions = true
gltfShape29.isPointerBlocker = true
gltfShape29.visible = true
dirtMound.addComponentOrReplace(gltfShape29)

const dirtClump = new Entity('dirtClump')
engine.addEntity(dirtClump)
dirtClump.setParent(_scene)
const transform180 = new Transform({
  position: new Vector3(4.5, 0, 2),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
dirtClump.addComponentOrReplace(transform180)
const gltfShape30 = new GLTFShape("6c501b29-1e92-4ae9-8b6a-b4fc3c6d375d/Dirt_02/Dirt_02.glb")
gltfShape30.withCollisions = true
gltfShape30.isPointerBlocker = true
gltfShape30.visible = true
dirtClump.addComponentOrReplace(gltfShape30)

const yellowBuds2 = new Entity('yellowBuds2')
engine.addEntity(yellowBuds2)
yellowBuds2.setParent(_scene)
yellowBuds2.addComponentOrReplace(gltfShape22)
const transform181 = new Transform({
  position: new Vector3(4.952566623687744, 0, 3.466343879699707),
  rotation: new Quaternion(-0.09776400774717331, -0.02733440324664116, -0.19333511590957642, 0.9758670926094055),
  scale: new Vector3(1.0000027418136597, 0.9999998807907104, 1.0000028610229492)
})
yellowBuds2.addComponentOrReplace(transform181)

const yellowBuds3 = new Entity('yellowBuds3')
engine.addEntity(yellowBuds3)
yellowBuds3.setParent(_scene)
yellowBuds3.addComponentOrReplace(gltfShape22)
const transform182 = new Transform({
  position: new Vector3(5.1585235595703125, 0, 3.3396620750427246),
  rotation: new Quaternion(0.24807953834533691, -0.8522560000419617, 0.17524310946464539, -0.4259181022644043),
  scale: new Vector3(1.0000039339065552, 1.000001072883606, 1.0000041723251343)
})
yellowBuds3.addComponentOrReplace(transform182)

const cactusWand2 = new Entity('cactusWand2')
engine.addEntity(cactusWand2)
cactusWand2.setParent(_scene)
cactusWand2.addComponentOrReplace(gltfShape27)
const transform183 = new Transform({
  position: new Vector3(1.01688814163208, 0.21756267547607422, 1.4744149446487427),
  rotation: new Quaternion(-0.07301575690507889, 0.5065462589263916, 0.06539154052734375, 0.8566234111785889),
  scale: new Vector3(1, 1, 1.0000007152557373)
})
cactusWand2.addComponentOrReplace(transform183)

const cactusWand3 = new Entity('cactusWand3')
engine.addEntity(cactusWand3)
cactusWand3.setParent(_scene)
cactusWand3.addComponentOrReplace(gltfShape27)
const transform184 = new Transform({
  position: new Vector3(0.7657834887504578, 0.1764211654663086, 1.768428087234497),
  rotation: new Quaternion(-1.9682441067877133e-15, 0.9951847791671753, -1.1863526339084274e-7, 0.0980171263217926),
  scale: new Vector3(1.0000016689300537, 1, 1.0000016689300537)
})
cactusWand3.addComponentOrReplace(transform184)

const yellowBuds4 = new Entity('yellowBuds4')
engine.addEntity(yellowBuds4)
yellowBuds4.setParent(_scene)
yellowBuds4.addComponentOrReplace(gltfShape22)
const transform185 = new Transform({
  position: new Vector3(4.952566623687744, 0, 3.466343879699707),
  rotation: new Quaternion(-0.053406812250614166, 0.23518434166908264, 0.11889167129993439, 0.9631723165512085),
  scale: new Vector3(1.0000029802322388, 1, 1.0000028610229492)
})
yellowBuds4.addComponentOrReplace(transform185)

const dirtPatch2 = new Entity('dirtPatch2')
engine.addEntity(dirtPatch2)
dirtPatch2.setParent(_scene)
dirtPatch2.addComponentOrReplace(gltfShape28)
const transform186 = new Transform({
  position: new Vector3(5, 0, 3),
  rotation: new Quaternion(6.7109636905482006e-15, -0.3826834559440613, 4.5619440669497635e-8, 0.9238795638084412),
  scale: new Vector3(1, 1, 1)
})
dirtPatch2.addComponentOrReplace(transform186)

const dirtMound2 = new Entity('dirtMound2')
engine.addEntity(dirtMound2)
dirtMound2.setParent(_scene)
dirtMound2.addComponentOrReplace(gltfShape29)
const transform187 = new Transform({
  position: new Vector3(2.602839708328247, 0, 1.3690730333328247),
  rotation: new Quaternion(-3.434617380678991e-15, 0.08811676502227783, -1.0504326297677835e-8, 0.996110200881958),
  scale: new Vector3(1.0000019073486328, 1, 1.0000019073486328)
})
dirtMound2.addComponentOrReplace(transform187)

const dirtPatch3 = new Entity('dirtPatch3')
engine.addEntity(dirtPatch3)
dirtPatch3.setParent(_scene)
dirtPatch3.addComponentOrReplace(gltfShape28)
const transform188 = new Transform({
  position: new Vector3(1.1636879444122314, 0, 1.3737953901290894),
  rotation: new Quaternion(1.9369268423321748e-14, 0.11440636217594147, -1.3638287832407059e-8, 0.9934340715408325),
  scale: new Vector3(1.0000005960464478, 1, 1.0000005960464478)
})
dirtPatch3.addComponentOrReplace(transform188)

const cactusWand4 = new Entity('cactusWand4')
engine.addEntity(cactusWand4)
cactusWand4.setParent(_scene)
cactusWand4.addComponentOrReplace(gltfShape27)
const transform189 = new Transform({
  position: new Vector3(1.1934446096420288, 0.17268109321594238, 1.7343082427978516),
  rotation: new Quaternion(-0.05594063177704811, -0.8171887397766113, -0.08048596233129501, 0.5679746270179749),
  scale: new Vector3(0.9999999403953552, 0.9999999403953552, 0.9999998807907104)
})
cactusWand4.addComponentOrReplace(transform189)

const cactusWand5 = new Entity('cactusWand5')
engine.addEntity(cactusWand5)
cactusWand5.setParent(_scene)
cactusWand5.addComponentOrReplace(gltfShape27)
const transform190 = new Transform({
  position: new Vector3(1.066592812538147, 0.21756267547607422, 1.629364013671875),
  rotation: new Quaternion(-0.07301575690507889, 0.5065462589263916, 0.06539154052734375, 0.8566234111785889),
  scale: new Vector3(1, 1, 1.0000008344650269)
})
cactusWand5.addComponentOrReplace(transform190)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape31 = new GLTFShape("5213245c-db38-4195-8296-b15485230fa0/GroundFloorSciFi_03/GroundFloorSciFi_03.glb")
gltfShape31.withCollisions = true
gltfShape31.isPointerBlocker = true
gltfShape31.visible = true
entity.addComponentOrReplace(gltfShape31)
const transform191 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform191)

const dirtPatch4 = new Entity('dirtPatch4')
engine.addEntity(dirtPatch4)
dirtPatch4.setParent(_scene)
dirtPatch4.addComponentOrReplace(gltfShape28)
const transform192 = new Transform({
  position: new Vector3(5.5, 0, 1.5),
  rotation: new Quaternion(1.7046538063492794e-14, 0.2902846336364746, -3.46046178378856e-8, 0.9569404125213623),
  scale: new Vector3(1.000000238418579, 1, 1.000000238418579)
})
dirtPatch4.addComponentOrReplace(transform192)

const dirtPatch5 = new Entity('dirtPatch5')
engine.addEntity(dirtPatch5)
dirtPatch5.setParent(_scene)
dirtPatch5.addComponentOrReplace(gltfShape28)
const transform193 = new Transform({
  position: new Vector3(5.948863983154297, 0, 2.818641185760498),
  rotation: new Quaternion(2.1974182727330788e-14, 0.7690497040748596, -9.16778475357205e-8, -0.6391890048980713),
  scale: new Vector3(0.9999995231628418, 1, 0.9999995231628418)
})
dirtPatch5.addComponentOrReplace(transform193)

const greyFloorPanel2 = new Entity('greyFloorPanel2')
engine.addEntity(greyFloorPanel2)
greyFloorPanel2.setParent(_scene)
const gltfShape32 = new GLTFShape("13b9f9e1-7b20-40fc-a21b-ca2103026096/FloorSciFiPanel_01/FloorSciFiPanel_01.glb")
gltfShape32.withCollisions = true
gltfShape32.isPointerBlocker = true
gltfShape32.visible = true
greyFloorPanel2.addComponentOrReplace(gltfShape32)
const transform194 = new Transform({
  position: new Vector3(9, 0, 2),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.000000238418579, 1, 1.000000238418579)
})
greyFloorPanel2.addComponentOrReplace(transform194)

const greyFloorPanel = new Entity('greyFloorPanel')
engine.addEntity(greyFloorPanel)
greyFloorPanel.setParent(_scene)
greyFloorPanel.addComponentOrReplace(gltfShape32)
const transform195 = new Transform({
  position: new Vector3(9, 0, 0),
  rotation: new Quaternion(-2.4085271740892887e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.0000004768371582, 1, 1.0000004768371582)
})
greyFloorPanel.addComponentOrReplace(transform195)

const tealTreeBulb = new Entity('tealTreeBulb')
engine.addEntity(tealTreeBulb)
tealTreeBulb.setParent(_scene)
const transform196 = new Transform({
  position: new Vector3(4.218618869781494, 0.3712154030799866, 1.9263372421264648),
  rotation: new Quaternion(0.062044769525527954, 0.0445672869682312, -0.005824225023388863, 0.9970608949661255),
  scale: new Vector3(1.000004529953003, 0.9999999403953552, 1.000004529953003)
})
tealTreeBulb.addComponentOrReplace(transform196)
const gltfShape33 = new GLTFShape("a0338fcf-e109-45f1-8cfd-cea058c07c94/PlantSF_13/PlantSF_13.glb")
gltfShape33.withCollisions = true
gltfShape33.isPointerBlocker = true
gltfShape33.visible = true
tealTreeBulb.addComponentOrReplace(gltfShape33)

const wheeledRover = new Entity('wheeledRover')
engine.addEntity(wheeledRover)
wheeledRover.setParent(_scene)
const transform197 = new Transform({
  position: new Vector3(12.5, 0, 2),
  rotation: new Quaternion(9.350889677915523e-15, 0.7071067690849304, -8.429368136830817e-8, 0.70710688829422),
  scale: new Vector3(1.0000007152557373, 1, 1.0000007152557373)
})
wheeledRover.addComponentOrReplace(transform197)
const gltfShape34 = new GLTFShape("b9295675-6e07-4ca7-8726-7274ff82bbfa/Rover_01/Rover_01.glb")
gltfShape34.withCollisions = true
gltfShape34.isPointerBlocker = true
gltfShape34.visible = true
wheeledRover.addComponentOrReplace(gltfShape34)

const keyboard9 = new Entity('keyboard9')
engine.addEntity(keyboard9)
keyboard9.setParent(_scene)
const transform198 = new Transform({
  position: new Vector3(14.933063507080078, 5.1661834716796875, 12.5),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000066757202148, 1, 1.0000066757202148)
})
keyboard9.addComponentOrReplace(transform198)

const imageComputerScreen9 = new Entity('imageComputerScreen9')
engine.addEntity(imageComputerScreen9)
imageComputerScreen9.setParent(_scene)
const transform199 = new Transform({
  position: new Vector3(15.284796714782715, 5.277034282684326, 12.5),
  rotation: new Quaternion(2.977848511125005e-15, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(1.0000061988830566, 1, 1.0000061988830566)
})
imageComputerScreen9.addComponentOrReplace(transform199)

const externalLink9 = new Entity('externalLink9')
engine.addEntity(externalLink9)
externalLink9.setParent(_scene)
const transform200 = new Transform({
  position: new Vector3(15.680614471435547, 6.422111988067627, 12.762079238891602),
  rotation: new Quaternion(0.5, 0.5, -0.5000001192092896, -0.5),
  scale: new Vector3(1.0000113248825073, 1.0000112056732178, 1.0000110864639282)
})
externalLink9.addComponentOrReplace(transform200)

const concreteWall16 = new Entity('concreteWall16')
engine.addEntity(concreteWall16)
concreteWall16.setParent(_scene)
concreteWall16.addComponentOrReplace(gltfShape)
const transform201 = new Transform({
  position: new Vector3(6.633004188537598, 8.266433715820312, 16),
  rotation: new Quaternion(8.429370268459024e-8, -0.7071067690849304, 0.70710688829422, 1.8266401032810548e-15),
  scale: new Vector3(4.687020301818848, 2.9976260662078857, 1.0000098943710327)
})
concreteWall16.addComponentOrReplace(transform201)

const concreteWall17 = new Entity('concreteWall17')
engine.addEntity(concreteWall17)
concreteWall17.setParent(_scene)
concreteWall17.addComponentOrReplace(gltfShape)
const transform202 = new Transform({
  position: new Vector3(0, 8.266433715820312, 16),
  rotation: new Quaternion(8.429370268459024e-8, -0.7071067690849304, 0.70710688829422, 1.8266401032810548e-15),
  scale: new Vector3(4.687020301818848, 2.997624158859253, 1.0000108480453491)
})
concreteWall17.addComponentOrReplace(transform202)

const fullCurvedBarrier3 = new Entity('fullCurvedBarrier3')
engine.addEntity(fullCurvedBarrier3)
fullCurvedBarrier3.setParent(_scene)
fullCurvedBarrier3.addComponentOrReplace(gltfShape9)
const transform203 = new Transform({
  position: new Vector3(15.886433601379395, 4.285194396972656, 4.631397724151611),
  rotation: new Quaternion(-1.5394153601527394e-15, 0.7071068286895752, -8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.3836692571640015, 1, 1.0000042915344238)
})
fullCurvedBarrier3.addComponentOrReplace(transform203)

const imageFromURL5 = new Entity('imageFromURL5')
engine.addEntity(imageFromURL5)
imageFromURL5.setParent(_scene)
const transform204 = new Transform({
  position: new Vector3(7.5, 4.79503870010376, 3.9979734420776367),
  rotation: new Quaternion(-5.772643037952989e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(2.5, 3, 1)
})
imageFromURL5.addComponentOrReplace(transform204)

const imageFromURL2 = new Entity('imageFromURL2')
engine.addEntity(imageFromURL2)
imageFromURL2.setParent(_scene)
const transform205 = new Transform({
  position: new Vector3(3.5, 2.6490421295166016, 3.9913129806518555),
  rotation: new Quaternion(-5.772643037952989e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
imageFromURL2.addComponentOrReplace(transform205)

const hidrant = new Entity('hidrant')
engine.addEntity(hidrant)
hidrant.setParent(_scene)
const transform206 = new Transform({
  position: new Vector3(15.5, 0, 3.5),
  rotation: new Quaternion(9.35170537064373e-15, 1, -1.1920928244535389e-7, -5.960464477539063e-8),
  scale: new Vector3(1, 1, 1)
})
hidrant.addComponentOrReplace(transform206)
const gltfShape35 = new GLTFShape("4056088f-b6eb-40b0-b4d2-cd3360fff497/Hidrant.glb")
gltfShape35.withCollisions = true
gltfShape35.isPointerBlocker = true
gltfShape35.visible = true
hidrant.addComponentOrReplace(gltfShape35)

const ambientSound = new Entity('ambientSound')
engine.addEntity(ambientSound)
ambientSound.setParent(_scene)
const transform207 = new Transform({
  position: new Vector3(3, 0.5, 2.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
ambientSound.addComponentOrReplace(transform207)

const githubLink = new Entity('githubLink')
engine.addEntity(githubLink)
githubLink.setParent(_scene)
const transform208 = new Transform({
  position: new Vector3(12.5, 5.62473726272583, 9.33816146850586),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
githubLink.addComponentOrReplace(transform208)

const nftPictureFrame5 = new Entity('nftPictureFrame5')
engine.addEntity(nftPictureFrame5)
nftPictureFrame5.setParent(_scene)
const transform209 = new Transform({
  position: new Vector3(0.3201904296875, 1.7245209217071533, 7.498462200164795),
  rotation: new Quaternion(4.127578846475997e-15, -0.7071068286895752, 8.429370268459024e-8, -0.7071067690849304),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame5.addComponentOrReplace(transform209)

const nftPictureFrame6 = new Entity('nftPictureFrame6')
engine.addEntity(nftPictureFrame6)
nftPictureFrame6.setParent(_scene)
const transform210 = new Transform({
  position: new Vector3(0.3201904296875, 1.7245209217071533, 10.01143741607666),
  rotation: new Quaternion(4.127578846475997e-15, -0.7071068286895752, 8.429370268459024e-8, -0.7071067690849304),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame6.addComponentOrReplace(transform210)

const nftPictureFrame7 = new Entity('nftPictureFrame7')
engine.addEntity(nftPictureFrame7)
nftPictureFrame7.setParent(_scene)
const transform211 = new Transform({
  position: new Vector3(0.3201904296875, 1.7245209217071533, 12.542891502380371),
  rotation: new Quaternion(4.127578846475997e-15, -0.7071068286895752, 8.429370268459024e-8, -0.7071067690849304),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame7.addComponentOrReplace(transform211)

const nftPictureFrame8 = new Entity('nftPictureFrame8')
engine.addEntity(nftPictureFrame8)
nftPictureFrame8.setParent(_scene)
const transform212 = new Transform({
  position: new Vector3(15.668951034545898, 1.7245203256607056, 7.47551155090332),
  rotation: new Quaternion(1.1233005357044051e-14, -0.7071067690849304, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame8.addComponentOrReplace(transform212)

const nftPictureFrame9 = new Entity('nftPictureFrame9')
engine.addEntity(nftPictureFrame9)
nftPictureFrame9.setParent(_scene)
const transform213 = new Transform({
  position: new Vector3(15.668951034545898, 1.7245209217071533, 10.006965637207031),
  rotation: new Quaternion(1.1233005357044051e-14, -0.7071067690849304, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame9.addComponentOrReplace(transform213)

const nftPictureFrame10 = new Entity('nftPictureFrame10')
engine.addEntity(nftPictureFrame10)
nftPictureFrame10.setParent(_scene)
const transform214 = new Transform({
  position: new Vector3(15.668951034545898, 1.724521517753601, 12.519941329956055),
  rotation: new Quaternion(1.1233005357044051e-14, -0.7071067690849304, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame10.addComponentOrReplace(transform214)

const imageFromURL = new Entity('imageFromURL')
engine.addEntity(imageFromURL)
imageFromURL.setParent(_scene)
const transform215 = new Transform({
  position: new Vector3(12.5, 2.6490421295166016, 3.9913129806518555),
  rotation: new Quaternion(-5.772643037952989e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
imageFromURL.addComponentOrReplace(transform215)

const imageFromURL3 = new Entity('imageFromURL3')
engine.addEntity(imageFromURL3)
imageFromURL3.setParent(_scene)
const transform216 = new Transform({
  position: new Vector3(15.5, 2.6490421295166016, 3.9913129806518555),
  rotation: new Quaternion(-5.772643037952989e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
imageFromURL3.addComponentOrReplace(transform216)

const imageFromURL4 = new Entity('imageFromURL4')
engine.addEntity(imageFromURL4)
imageFromURL4.setParent(_scene)
const transform217 = new Transform({
  position: new Vector3(0.4999997615814209, 2.6490421295166016, 3.9913129806518555),
  rotation: new Quaternion(-5.772643037952989e-15, 1, -1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
imageFromURL4.addComponentOrReplace(transform217)

const nftPictureFrame11 = new Entity('nftPictureFrame11')
engine.addEntity(nftPictureFrame11)
nftPictureFrame11.setParent(_scene)
const transform218 = new Transform({
  position: new Vector3(0.3201904296875, 1.7245209217071533, 5.023540496826172),
  rotation: new Quaternion(4.127578846475997e-15, -0.7071068286895752, 8.429370268459024e-8, -0.7071067690849304),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame11.addComponentOrReplace(transform218)

const nftPictureFrame12 = new Entity('nftPictureFrame12')
engine.addEntity(nftPictureFrame12)
nftPictureFrame12.setParent(_scene)
const transform219 = new Transform({
  position: new Vector3(0.3201904296875, 1.7245209217071533, 15.009089469909668),
  rotation: new Quaternion(4.127578846475997e-15, -0.7071068286895752, 8.429370268459024e-8, -0.7071067690849304),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame12.addComponentOrReplace(transform219)

const nftPictureFrame13 = new Entity('nftPictureFrame13')
engine.addEntity(nftPictureFrame13)
nftPictureFrame13.setParent(_scene)
const transform220 = new Transform({
  position: new Vector3(15.668951034545898, 1.7245203256607056, 5.005115032196045),
  rotation: new Quaternion(1.1233005357044051e-14, -0.7071067690849304, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame13.addComponentOrReplace(transform220)

const nftPictureFrame14 = new Entity('nftPictureFrame14')
engine.addEntity(nftPictureFrame14)
nftPictureFrame14.setParent(_scene)
const transform221 = new Transform({
  position: new Vector3(15.668951034545898, 1.724521517753601, 14.980973243713379),
  rotation: new Quaternion(1.1233005357044051e-14, -0.7071067690849304, 8.429368847373553e-8, 0.7071068286895752),
  scale: new Vector3(1, 1, 1)
})
nftPictureFrame14.addComponentOrReplace(transform221)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
const script6 = new Script6()
const script7 = new Script7()
const script8 = new Script8()
const script9 = new Script9()
const script10 = new Script10()
const script11 = new Script11()
const script12 = new Script12()
const script13 = new Script13()
const script14 = new Script14()
const script15 = new Script15()
const script16 = new Script16()
const script17 = new Script17()
const script18 = new Script18()
const script19 = new Script19()
const script20 = new Script20()
const script21 = new Script21()
const script22 = new Script22()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script6.init(options)
script7.init(options)
script8.init(options)
script9.init(options)
script10.init(options)
script11.init(options)
script12.init(options)
script13.init(options)
script14.init(options)
script15.init(options)
script16.init(options)
script17.init(options)
script18.init(options)
script19.init(options)
script20.init(options)
script21.init(options)
script22.init(options)
script1.spawn(externalLink, {"url":"decentraland.org"}, createChannel(channelId, externalLink, channelBus))
script2.spawn(openAndClosedSign, {"startOn":true,"clickable":false}, createChannel(channelId, openAndClosedSign, channelBus))
script3.spawn(speakers, {"clickable":true,"onActivate":[]}, createChannel(channelId, speakers, channelBus))
script4.spawn(scifiChest, {"onClickText":"Open/Close","onClick":[{"entityName":"scifiChest","actionId":"toggle","values":{}}]}, createChannel(channelId, scifiChest, channelBus))
script5.spawn(atomicLight, {"startOn":true,"clickable":true}, createChannel(channelId, atomicLight, channelBus))
script6.spawn(ceilingFan, {"onActivate":[]}, createChannel(channelId, ceilingFan, channelBus))
script7.spawn(ceilingLight, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight, channelBus))
script8.spawn(imageComputerScreen, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageComputerScreen, channelBus))
script9.spawn(verticalPlatform, {"distance":4,"speed":5,"autoStart":false,"onReachEnd":[],"onReachStart":[]}, createChannel(channelId, verticalPlatform, channelBus))
script10.spawn(keyboard3, {"onClick":[{"entityName":"externalLink","actionId":"activate","values":{}}]}, createChannel(channelId, keyboard3, channelBus))
script6.spawn(ceilingFan2, {}, createChannel(channelId, ceilingFan2, channelBus))
script3.spawn(speakers2, {"clickable":true,"onActivate":[]}, createChannel(channelId, speakers2, channelBus))
script10.spawn(keyboard, {"onClick":[{"entityName":"externalLink","actionId":"activate","values":{}}]}, createChannel(channelId, keyboard, channelBus))
script8.spawn(imageComputerScreen2, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageComputerScreen2, channelBus))
script10.spawn(keyboard4, {"onClick":[{"entityName":"externalLink","actionId":"activate","values":{}}]}, createChannel(channelId, keyboard4, channelBus))
script8.spawn(imageComputerScreen4, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageComputerScreen4, channelBus))
script10.spawn(keyboard5, {"onClick":[{"entityName":"externalLink","actionId":"activate","values":{}}]}, createChannel(channelId, keyboard5, channelBus))
script8.spawn(imageComputerScreen5, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageComputerScreen5, channelBus))
script1.spawn(externalLink5, {"url":"decentraland.org"}, createChannel(channelId, externalLink5, channelBus))
script1.spawn(externalLink6, {"url":"decentraland.org"}, createChannel(channelId, externalLink6, channelBus))
script1.spawn(externalLink7, {"url":"decentraland.org"}, createChannel(channelId, externalLink7, channelBus))
script7.spawn(ceilingLight2, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight2, channelBus))
script7.spawn(ceilingLight3, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight3, channelBus))
script7.spawn(ceilingLight4, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight4, channelBus))
script11.spawn(blueLightButton, {"onClick":[{"entityName":"cyberpunkDoor2","actionId":"toggle","values":{}},{"entityName":"ceilingFan","actionId":"activate","values":{}},{"entityName":"ceilingFan2","actionId":"activate","values":{}}]}, createChannel(channelId, blueLightButton, channelBus))
script11.spawn(blueLightButton2, {"onClick":[{"entityName":"cyberpunkDoor2","actionId":"toggle","values":{}}]}, createChannel(channelId, blueLightButton2, channelBus))
script12.spawn(cyberpunkDoor2, {"onClickText":"Use Switch","onClick":[]}, createChannel(channelId, cyberpunkDoor2, channelBus))
script1.spawn(externalLink2, {"url":"decentraland.org"}, createChannel(channelId, externalLink2, channelBus))
script1.spawn(externalLink3, {"url":"decentraland.org"}, createChannel(channelId, externalLink3, channelBus))
script1.spawn(externalLink4, {"url":"decentraland.org"}, createChannel(channelId, externalLink4, channelBus))
script1.spawn(externalLink8, {"url":"decentraland.org"}, createChannel(channelId, externalLink8, channelBus))
script7.spawn(ceilingLight5, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight5, channelBus))
script7.spawn(ceilingLight6, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight6, channelBus))
script7.spawn(ceilingLight7, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight7, channelBus))
script7.spawn(ceilingLight8, {"startOn":true,"clickable":true}, createChannel(channelId, ceilingLight8, channelBus))
script8.spawn(imageComputerScreen3, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageComputerScreen3, channelBus))
script10.spawn(keyboard2, {"onClick":[{"entityName":"externalLink","actionId":"activate","values":{}}]}, createChannel(channelId, keyboard2, channelBus))
script10.spawn(keyboard6, {"onClick":[{"entityName":"externalLink","actionId":"activate","values":{}}]}, createChannel(channelId, keyboard6, channelBus))
script8.spawn(imageComputerScreen6, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageComputerScreen6, channelBus))
script10.spawn(keyboard7, {"onClick":[{"entityName":"externalLink","actionId":"activate","values":{}}]}, createChannel(channelId, keyboard7, channelBus))
script8.spawn(imageComputerScreen7, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageComputerScreen7, channelBus))
script10.spawn(keyboard8, {"onClick":[{"entityName":"externalLink","actionId":"activate","values":{}}]}, createChannel(channelId, keyboard8, channelBus))
script8.spawn(imageComputerScreen8, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageComputerScreen8, channelBus))
script13.spawn(nftPictureFrame, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame, channelBus))
script13.spawn(nftPictureFrame2, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame2, channelBus))
script13.spawn(nftPictureFrame3, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame3, channelBus))
script14.spawn(videoStream, {"startOn":"false","onClickText":"Play video","volume":1,"onClick":[{"entityName":"videoStream","actionId":"toggle","values":{}}]}, createChannel(channelId, videoStream, channelBus))
script14.spawn(videoStream2, {"startOn":"false","onClickText":"Play video","volume":1,"onClick":[{"entityName":"videoStream2","actionId":"toggle","values":{}}]}, createChannel(channelId, videoStream2, channelBus))
script13.spawn(nftPictureFrame4, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame4, channelBus))
script15.spawn(microwave, {"clickable":true}, createChannel(channelId, microwave, channelBus))
script16.spawn(qrScifiFrame, {"publicKey":"0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx","text":"Make a donation","fontSize":15}, createChannel(channelId, qrScifiFrame, channelBus))
script17.spawn(slushieMachine, {"clickable":true}, createChannel(channelId, slushieMachine, channelBus))
script18.spawn(greenLightButton, {"onClick":[{"entityName":"verticalPlatform","actionId":"goToEnd","values":{}}]}, createChannel(channelId, greenLightButton, channelBus))
script14.spawn(videoStream3, {"startOn":"false","onClickText":"Play video","volume":1,"onClick":[{"entityName":"videoStream3","actionId":"toggle","values":{}}]}, createChannel(channelId, videoStream3, channelBus))
script19.spawn(redLightButton, {"onClick":[{"entityName":"verticalPlatform","actionId":"goToStart","values":{}}]}, createChannel(channelId, redLightButton, channelBus))
script18.spawn(greenLightButton3, {"onClick":[{"entityName":"verticalPlatform","actionId":"goToEnd","values":{}}]}, createChannel(channelId, greenLightButton3, channelBus))
script19.spawn(redLightButton2, {"onClick":[{"entityName":"verticalPlatform","actionId":"goToStart","values":{}}]}, createChannel(channelId, redLightButton2, channelBus))
script10.spawn(keyboard9, {"onClick":[{"entityName":"externalLink","actionId":"activate","values":{}}]}, createChannel(channelId, keyboard9, channelBus))
script8.spawn(imageComputerScreen9, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageComputerScreen9, channelBus))
script1.spawn(externalLink9, {"url":"decentraland.org"}, createChannel(channelId, externalLink9, channelBus))
script20.spawn(imageFromURL5, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageFromURL5, channelBus))
script20.spawn(imageFromURL2, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageFromURL2, channelBus))
script21.spawn(ambientSound, {"sound":"Birds","active":true,"loop":true}, createChannel(channelId, ambientSound, channelBus))
script22.spawn(githubLink, {"url":"decentraland","bnw":false}, createChannel(channelId, githubLink, channelBus))
script13.spawn(nftPictureFrame5, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame5, channelBus))
script13.spawn(nftPictureFrame6, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame6, channelBus))
script13.spawn(nftPictureFrame7, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame7, channelBus))
script13.spawn(nftPictureFrame8, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame8, channelBus))
script13.spawn(nftPictureFrame9, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame9, channelBus))
script13.spawn(nftPictureFrame10, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame10, channelBus))
script20.spawn(imageFromURL, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageFromURL, channelBus))
script20.spawn(imageFromURL3, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageFromURL3, channelBus))
script20.spawn(imageFromURL4, {"image":"https://i.imgur.com/d25gO61.jpg"}, createChannel(channelId, imageFromURL4, channelBus))
script13.spawn(nftPictureFrame11, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame11, channelBus))
script13.spawn(nftPictureFrame12, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame12, channelBus))
script13.spawn(nftPictureFrame13, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame13, channelBus))
script13.spawn(nftPictureFrame14, {"id":"558536","contract":"0x06012c8cf97BEaD5deAe237070F9587f8E7A266d","style":"Classic","color":"#FFFFFF","ui":true}, createChannel(channelId, nftPictureFrame14, channelBus))